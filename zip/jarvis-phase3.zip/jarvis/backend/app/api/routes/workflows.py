"""Workflow REST + WebSocket API.

GET  /workflows/templates    list registered template names
GET  /workflows              list all DAGs (summary)
POST /workflows              create + optionally start a workflow
GET  /workflows/{id}         full DAG with node statuses
POST /workflows/{id}/start   start (or restart) an existing DAG
POST /workflows/{id}/cancel  cancel all pending nodes
WS   /workflows/{id}/ws      live node-status stream for one DAG
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect

from app.api.deps import get_agents
from app.domain.enums import AgentRole, TaskStatus
from app.workflows.dag import WorkflowDAG
from app.workflows.executor import DAGExecutor
from app.workflows.registry import template_registry

router = APIRouter(prefix="/workflows", tags=["workflows"])


# ── dependency: always pull the single executor from app.state ────────────────
def get_executor(request: Request) -> DAGExecutor:
    ex: DAGExecutor | None = getattr(request.app.state, "dag_executor", None)
    if ex is None:
        # bootstrap fallback for bare uvicorn / test clients that skip lifespan
        agents = request.app.state.agents if hasattr(request.app.state, "agents") else None
        ex = DAGExecutor(agents)
        request.app.state.dag_executor = ex
    return ex


# ── helpers ───────────────────────────────────────────────────────────────────
def _dag_from_spec(spec: dict) -> WorkflowDAG:
    dag = WorkflowDAG(name=spec.get("name", "workflow"))
    for n in spec.get("nodes", []):
        dag.add_node(
            objective=n["objective"],
            role=AgentRole(n.get("role", "research")),
            node_id=n.get("id"),
            max_retries=n.get("max_retries", 2),
            timeout_s=n.get("timeout_s", 120.0),
        )
    for e in spec.get("edges", []):
        dag.add_edge(e["src"], e["dst"])
    return dag


def _summary(dag: WorkflowDAG) -> dict:
    total  = len(dag.nodes)
    done   = sum(1 for n in dag.nodes.values() if n.status == TaskStatus.SUCCEEDED)
    failed = sum(1 for n in dag.nodes.values() if n.status == TaskStatus.FAILED)
    return {
        "id": dag.id, "name": dag.name,
        "nodes_total": total, "nodes_done": done, "nodes_failed": failed,
        "dead_letters": len(dag.dead_letters),
        "complete": dag.is_complete(),
        "created_at": dag.created_at.isoformat(),
    }


# ── REST endpoints ────────────────────────────────────────────────────────────
@router.get("/templates")
async def list_templates() -> list[str]:
    return template_registry.list()


@router.get("")
async def list_workflows(ex: DAGExecutor = Depends(get_executor)) -> list[dict]:
    return [_summary(d) for d in ex.list()]


@router.post("")
async def create_workflow(
    body: dict,
    ex: DAGExecutor = Depends(get_executor),
) -> dict:
    try:
        if "template" in body:
            dag = template_registry.build(body["template"], **(body.get("params") or {}))
        elif "nodes" in body:
            dag = _dag_from_spec(body)
        else:
            raise HTTPException(422, "Provide 'template' or 'nodes'")
        dag.validate()
    except (KeyError, ValueError) as exc:
        raise HTTPException(422, str(exc)) from exc

    auto_start = body.get("start", False)
    if auto_start:
        ex.submit(dag)
    else:
        ex._dags[dag.id] = dag  # register without running

    return {"id": dag.id, "started": auto_start, **_summary(dag)}


@router.get("/{dag_id}")
async def get_workflow(
    dag_id: str,
    ex: DAGExecutor = Depends(get_executor),
) -> dict:
    dag = ex.get(dag_id)
    if dag is None:
        raise HTTPException(404, f"Workflow {dag_id!r} not found")
    return dag.to_dict()


@router.post("/{dag_id}/start")
async def start_workflow(
    dag_id: str,
    ex: DAGExecutor = Depends(get_executor),
) -> dict:
    dag = ex.get(dag_id)
    if dag is None:
        raise HTTPException(404, f"Workflow {dag_id!r} not found")
    if dag.is_complete():
        raise HTTPException(409, "Workflow already complete")
    ex.submit(dag)
    return {"id": dag_id, "started": True}


@router.post("/{dag_id}/cancel")
async def cancel_workflow(
    dag_id: str,
    ex: DAGExecutor = Depends(get_executor),
) -> dict:
    dag = ex.get(dag_id)
    if dag is None:
        raise HTTPException(404, f"Workflow {dag_id!r} not found")
    cancelled = sum(
        1 for n in dag.nodes.values()
        if n.status == TaskStatus.PENDING and setattr(n, "status", TaskStatus.CANCELLED) is None
    )
    return {"id": dag_id, "cancelled_nodes": cancelled}


# ── WebSocket live feed ───────────────────────────────────────────────────────
@router.websocket("/{dag_id}/ws")
async def workflow_ws(
    dag_id: str,
    ws: WebSocket,
    ex: DAGExecutor = Depends(get_executor),
) -> None:
    await ws.accept()
    try:
        while True:
            dag = ex.get(dag_id)
            if dag:
                await ws.send_json(dag.to_dict())
                if dag.is_complete():
                    break
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        pass
