"""Named workflow templates.

A template is a factory function that builds a WorkflowDAG from parameters.
Register your own with @template_registry.register("my-workflow").
"""
from __future__ import annotations

from typing import Callable

from app.domain.enums import AgentRole
from app.workflows.conditions import confidence_high, confidence_low, no_error
from app.workflows.dag import WorkflowDAG


TemplateFactory = Callable[..., WorkflowDAG]


class _TemplateRegistry:
    def __init__(self) -> None:
        self._templates: dict[str, TemplateFactory] = {}

    def register(self, name: str) -> Callable[[TemplateFactory], TemplateFactory]:
        def decorator(fn: TemplateFactory) -> TemplateFactory:
            self._templates[name] = fn
            return fn
        return decorator

    def build(self, name: str, **kwargs) -> WorkflowDAG:
        if name not in self._templates:
            raise KeyError(f"Unknown workflow template: {name!r}. "
                           f"Available: {list(self._templates)}")
        return self._templates[name](**kwargs)

    def list(self) -> list[str]:
        return list(self._templates)


template_registry = _TemplateRegistry()


# ── Built-in templates ────────────────────────────────────────────────────────

@template_registry.register("research-report")
def _research_report(topic: str = "AI trends") -> WorkflowDAG:
    """
    research ──► analysis ──► executive (report)
                          └──► (re-research if confidence low)
    """
    dag = WorkflowDAG(name="research-report")
    r = dag.add_node(f"Research: {topic}", AgentRole.RESEARCH, max_retries=3, timeout_s=90)
    a = dag.add_node(f"Analyse findings on {topic}", AgentRole.ANALYSIS, max_retries=2)
    e = dag.add_node(f"Write executive report on {topic}", AgentRole.EXECUTIVE)
    dag.add_edge(r.id, a.id)
    dag.add_edge(a.id, e.id, condition=no_error)
    return dag


@template_registry.register("research-report-with-retry")
def _research_report_retry(topic: str = "AI trends") -> WorkflowDAG:
    """
    research ──(high-confidence)──► analysis ──► executive
             └──(low-confidence)──► deep-research ──► analysis
    """
    dag = WorkflowDAG(name="research-report-with-retry")
    r  = dag.add_node(f"Research: {topic}",       AgentRole.RESEARCH, max_retries=2, timeout_s=90)
    dr = dag.add_node(f"Deep research: {topic}",  AgentRole.RESEARCH, max_retries=3, timeout_s=120)
    a  = dag.add_node(f"Analyse: {topic}",        AgentRole.ANALYSIS)
    e  = dag.add_node(f"Executive report: {topic}", AgentRole.EXECUTIVE)
    dag.add_edge(r.id,  a.id,  condition=confidence_high)
    dag.add_edge(r.id,  dr.id, condition=confidence_low)
    dag.add_edge(dr.id, a.id)
    dag.add_edge(a.id,  e.id)
    return dag


@template_registry.register("code-review")
def _code_review(repo: str = "main") -> WorkflowDAG:
    """analysis ──► coding (fixes) ──► executive (summary)"""
    dag = WorkflowDAG(name="code-review")
    a = dag.add_node(f"Analyse code quality in {repo}", AgentRole.ANALYSIS, timeout_s=60)
    c = dag.add_node(f"Apply fixes and refactor {repo}", AgentRole.CODING,  timeout_s=120)
    e = dag.add_node(f"Summarise code review for {repo}", AgentRole.EXECUTIVE)
    dag.add_edge(a.id, c.id, condition=no_error)
    dag.add_edge(c.id, e.id)
    return dag


@template_registry.register("parallel-research")
def _parallel_research(topics: list[str] | None = None) -> WorkflowDAG:
    """N parallel research tasks → single synthesis."""
    topics = topics or ["NVIDIA", "AMD", "Intel"]
    dag = WorkflowDAG(name="parallel-research")
    research_nodes = [
        dag.add_node(f"Research: {t}", AgentRole.RESEARCH, max_retries=2, timeout_s=90)
        for t in topics
    ]
    synth = dag.add_node("Synthesise all research into a unified report", AgentRole.EXECUTIVE)
    for n in research_nodes:
        dag.add_edge(n.id, synth.id)
    return dag
