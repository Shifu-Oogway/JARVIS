"""DAG data model.

WorkflowDAG owns nodes (DAGNode) and directed edges (DAGEdge).
Edges carry an optional condition predicate evaluated against the
upstream node's result before the downstream node becomes eligible.

The only runtime-free operation here is topology: finding the next
wave of ready nodes, detecting cycles, serialising to dict.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable
from uuid import uuid4

from app.domain.enums import AgentRole, TaskStatus


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uid() -> str:
    return str(uuid4())


# A condition is a callable that receives the upstream result string
# and returns True (follow this edge) or False (skip it).
Condition = Callable[[str], bool]


@dataclass
class DAGNode:
    id: str
    objective: str
    role: AgentRole
    max_retries: int = 2
    timeout_s: float = 120.0
    # runtime state
    status: TaskStatus = TaskStatus.PENDING
    result: str | None = None
    error: str | None = None
    attempt: int = 0
    started_at: datetime | None = None
    finished_at: datetime | None = None

    def to_dict(self) -> dict:
        return {
            "id": self.id, "objective": self.objective, "role": self.role,
            "status": self.status, "result": self.result, "error": self.error,
            "attempt": self.attempt,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
        }


@dataclass
class DAGEdge:
    src: str          # upstream node id
    dst: str          # downstream node id
    condition: Condition | None = None   # None → always follow

    def evaluate(self, result: str) -> bool:
        return self.condition(result) if self.condition else True


@dataclass
class WorkflowDAG:
    id: str = field(default_factory=_uid)
    name: str = "workflow"
    nodes: dict[str, DAGNode] = field(default_factory=dict)
    edges: list[DAGEdge] = field(default_factory=list)
    dead_letters: list[dict] = field(default_factory=list)
    created_at: datetime = field(default_factory=_now)

    # ── construction helpers ────────────────────────────────────────────────
    def add_node(self, objective: str, role: AgentRole, *,
                 node_id: str | None = None,
                 max_retries: int = 2,
                 timeout_s: float = 120.0) -> DAGNode:
        n = DAGNode(id=node_id or _uid(), objective=objective,
                    role=role, max_retries=max_retries, timeout_s=timeout_s)
        self.nodes[n.id] = n
        return n

    def add_edge(self, src: str, dst: str,
                 condition: Condition | None = None) -> None:
        if src not in self.nodes or dst not in self.nodes:
            raise ValueError(f"Edge references unknown node(s): {src!r} → {dst!r}")
        self.edges.append(DAGEdge(src=src, dst=dst, condition=condition))

    # ── topology ───────────────────────────────────────────────────────────
    def validate(self) -> None:
        """Raise ValueError if the graph contains a cycle."""
        visited: set[str] = set()
        path: set[str] = set()
        adj: dict[str, list[str]] = {nid: [] for nid in self.nodes}
        for e in self.edges:
            adj[e.src].append(e.dst)

        def dfs(n: str) -> None:
            visited.add(n)
            path.add(n)
            for nb in adj.get(n, []):
                if nb not in visited:
                    dfs(nb)
                elif nb in path:
                    raise ValueError(f"Cycle detected involving node {nb!r}")
            path.discard(n)

        for nid in self.nodes:
            if nid not in visited:
                dfs(nid)

    def _upstream_ids(self, node_id: str) -> list[str]:
        return [e.src for e in self.edges if e.dst == node_id]

    def _upstream_edges(self, node_id: str) -> list[DAGEdge]:
        return [e for e in self.edges if e.dst == node_id]

    def ready_nodes(self) -> list[DAGNode]:
        """
        A node is ready when it is PENDING and ALL upstream nodes that have
        an edge leading to it are SUCCEEDED and their edge conditions pass.
        Nodes with no upstream edges are root nodes — ready immediately.
        """
        ready = []
        for node in self.nodes.values():
            if node.status != TaskStatus.PENDING:
                continue
            up_edges = self._upstream_edges(node.id)
            if not up_edges:
                ready.append(node)
                continue
            if all(
                self.nodes[e.src].status == TaskStatus.SUCCEEDED
                and e.evaluate(self.nodes[e.src].result or "")
                for e in up_edges
            ):
                ready.append(node)
        return ready

    def is_complete(self) -> bool:
        return all(
            n.status in (TaskStatus.SUCCEEDED, TaskStatus.FAILED, TaskStatus.CANCELLED)
            for n in self.nodes.values()
        )

    def inject_nodes(self, new_nodes: list[DAGNode],
                     new_edges: list[DAGEdge]) -> None:
        """Graft additional nodes into a running DAG (dynamic spawning)."""
        for n in new_nodes:
            self.nodes[n.id] = n
        self.edges.extend(new_edges)

    # ── serialisation ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name,
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [{"src": e.src, "dst": e.dst,
                       "has_condition": e.condition is not None}
                      for e in self.edges],
            "dead_letters": self.dead_letters,
            "created_at": self.created_at.isoformat(),
        }
