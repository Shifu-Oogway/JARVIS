"""DAG Executor — the Phase 3 runtime engine.

Features
────────
• Wave-based parallel execution        asyncio.gather on each ready wave
• Per-node retries + exponential backoff   max_retries × 2^attempt delay
• Per-node timeouts                    asyncio.wait_for
• Redis checkpointing                  survives backend restarts
• Dead-letter queue                    nodes that exhaust retries
• Conditional edge evaluation          conditions.py predicates
• Dynamic node injection               agent returns JSON sub-plan
• Semaphore-bounded concurrency        prevents NIM rate-limit storms
• Live event emission                  event_bus feeds the WS dashboard
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone

import redis.asyncio as aioredis

from app.core.config import get_settings
from app.core.events import event_bus
from app.core.logging import get_logger
from app.domain.enums import AgentRole, TaskStatus
from app.infrastructure.nim.client import NIMError
from app.workflows.dag import DAGEdge, DAGNode, WorkflowDAG

log = get_logger("workflow.executor")

_MAX_CONCURRENT = 6          # max nodes running simultaneously
_CHECKPOINT_TTL = 60 * 60 * 24  # Redis TTL: 24 h


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── Dynamic sub-plan parser ───────────────────────────────────────────────────

def _parse_dynamic(result: str, parent_id: str) -> tuple[list[DAGNode], list[DAGEdge]]:
    """
    If an agent result starts with {"subtasks": [...]} inject new nodes.
    Each subtask: {"objective": str, "role": str}
    The first subtask depends on the parent; the rest chain sequentially.
    """
    try:
        data = json.loads(result)
        items = data.get("subtasks", [])
        if not items:
            return [], []
    except (json.JSONDecodeError, AttributeError):
        return [], []

    nodes: list[DAGNode] = []
    edges: list[DAGEdge] = []
    prev = parent_id

    for item in items:
        try:
            role = AgentRole(item.get("role", "research"))
        except ValueError:
            role = AgentRole.RESEARCH
        n = DAGNode(
            id=f"dyn-{int(time.time()*1000)}-{len(nodes)}",
            objective=item["objective"], role=role,
        )
        nodes.append(n)
        edges.append(DAGEdge(src=prev, dst=n.id))
        prev = n.id

    return nodes, edges


# ── Checkpointing ─────────────────────────────────────────────────────────────

class _Checkpoint:
    def __init__(self) -> None:
        self._r: aioredis.Redis | None = None

    async def _client(self) -> aioredis.Redis | None:
        if self._r is not None:
            return self._r
        try:
            self._r = aioredis.from_url(get_settings().redis_url, decode_responses=True)
            await self._r.ping()
        except Exception:  # noqa: BLE001
            self._r = None
        return self._r

    def _key(self, wf_id: str, node_id: str) -> str:
        return f"jarvis:wf:{wf_id}:node:{node_id}"

    async def save(self, wf_id: str, node: DAGNode) -> None:
        r = await self._client()
        if not r:
            return
        try:
            await r.set(
                self._key(wf_id, node.id),
                json.dumps({"status": node.status, "result": node.result,
                            "error": node.error, "attempt": node.attempt}),
                ex=_CHECKPOINT_TTL,
            )
        except Exception:  # noqa: BLE001
            pass

    async def restore(self, wf_id: str, dag: WorkflowDAG) -> int:
        """Restore completed nodes from Redis; returns count restored."""
        r = await self._client()
        if not r:
            return 0
        restored = 0
        for node in dag.nodes.values():
            raw = await r.get(self._key(wf_id, node.id))
            if raw:
                data = json.loads(raw)
                node.status = TaskStatus(data["status"])
                node.result = data.get("result")
                node.error = data.get("error")
                node.attempt = data.get("attempt", 0)
                restored += 1
        return restored


_checkpoint = _Checkpoint()


# ── Executor ──────────────────────────────────────────────────────────────────

class DAGExecutor:
    def __init__(self, agents) -> None:  # agents: AgentRegistry (avoid circular import)
        self._agents = agents
        self._sem = asyncio.Semaphore(_MAX_CONCURRENT)
        # in-memory store of all DAGs (keyed by dag.id); production would use DB
        self._dags: dict[str, WorkflowDAG] = {}

    def get(self, dag_id: str) -> WorkflowDAG | None:
        return self._dags.get(dag_id)

    def list(self) -> list[WorkflowDAG]:
        return list(self._dags.values())

    # ── single-node runner ────────────────────────────────────────────────
    async def _run_node(self, dag: WorkflowDAG, node: DAGNode) -> None:
        async with self._sem:
            node.status = TaskStatus.RUNNING
            node.started_at = _now()
            await event_bus.publish("node.started",
                                    {"dag": dag.id, "node": node.id, "role": node.role})

            # build context from upstream results
            context = "\n".join(
                f"[{dag.nodes[e.src].role}]: {dag.nodes[e.src].result}"
                for e in dag.edges
                if e.dst == node.id and dag.nodes[e.src].result
            )

            delay = 1.0
            for attempt in range(node.max_retries + 1):
                node.attempt = attempt
                try:
                    agent = self._agents.get(node.role)
                    result = await asyncio.wait_for(
                        agent.run(node.objective, context=context),
                        timeout=node.timeout_s,
                    )
                    node.status = TaskStatus.SUCCEEDED
                    node.result = result
                    node.finished_at = _now()

                    # dynamic node injection
                    new_nodes, new_edges = _parse_dynamic(result, node.id)
                    if new_nodes:
                        dag.inject_nodes(new_nodes, new_edges)
                        await event_bus.publish("dag.expanded",
                                                {"dag": dag.id, "injected": len(new_nodes)})

                    await _checkpoint.save(dag.id, node)
                    await event_bus.publish("node.succeeded",
                                            {"dag": dag.id, "node": node.id})
                    return

                except asyncio.TimeoutError:
                    node.error = f"Timeout after {node.timeout_s}s (attempt {attempt + 1})"
                    await event_bus.publish("node.timeout",
                                            {"dag": dag.id, "node": node.id, "attempt": attempt})
                except (NIMError, Exception) as exc:  # noqa: BLE001
                    node.error = str(exc)
                    await event_bus.publish("node.error",
                                            {"dag": dag.id, "node": node.id,
                                             "attempt": attempt, "error": node.error})

                if attempt < node.max_retries:
                    log.info("node_retry", dag=dag.id, node=node.id, delay=delay)
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 30)

            # exhausted — dead-letter
            node.status = TaskStatus.FAILED
            node.finished_at = _now()
            dlq_entry = {"node_id": node.id, "role": node.role,
                         "objective": node.objective, "error": node.error,
                         "attempts": node.attempt + 1}
            dag.dead_letters.append(dlq_entry)
            await _checkpoint.save(dag.id, node)
            await event_bus.publish("node.dead_letter",
                                    {"dag": dag.id, **dlq_entry})

    # ── wave executor ─────────────────────────────────────────────────────
    async def execute(self, dag: WorkflowDAG) -> WorkflowDAG:
        self._dags[dag.id] = dag
        dag.validate()

        # restore any previously checkpointed progress
        restored = await _checkpoint.restore(dag.id, dag)
        if restored:
            log.info("checkpoint_restored", dag=dag.id, nodes=restored)

        await event_bus.publish("dag.started", {"dag": dag.id, "name": dag.name,
                                                 "nodes": len(dag.nodes)})
        while not dag.is_complete():
            wave = dag.ready_nodes()
            if not wave:
                # no progress possible — cancel remaining pending nodes
                for n in dag.nodes.values():
                    if n.status == TaskStatus.PENDING:
                        n.status = TaskStatus.CANCELLED
                await event_bus.publish("dag.stalled", {"dag": dag.id})
                break

            await asyncio.gather(*(self._run_node(dag, n) for n in wave))

        status = (
            "completed" if all(n.status == TaskStatus.SUCCEEDED for n in dag.nodes.values())
            else "failed" if dag.dead_letters
            else "partial"
        )
        await event_bus.publish("dag.finished", {"dag": dag.id, "status": status,
                                                  "dead_letters": len(dag.dead_letters)})
        return dag

    # ── background fire-and-forget ────────────────────────────────────────
    def submit(self, dag: WorkflowDAG) -> asyncio.Task:
        return asyncio.create_task(self.execute(dag))
