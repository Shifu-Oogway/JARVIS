"""Built-in edge condition predicates.

Conditions are plain callables (str) → bool so they survive serialisation
without pickling — just store the condition *name* in the workflow template
and look it up here at load time.
"""
from __future__ import annotations

import json
import re


def always(result: str) -> bool:
    """Unconditional — same as no condition."""
    return True


def not_empty(result: str) -> bool:
    return bool(result.strip())


def confidence_high(result: str) -> bool:
    """Pass if the upstream result contains a confidence ≥ 0.9 marker."""
    m = re.search(r"confidence[:\s]+([0-9.]+)", result, re.I)
    return float(m.group(1)) >= 0.9 if m else False


def confidence_low(result: str) -> bool:
    return not confidence_high(result)


def contains_error(result: str) -> bool:
    return bool(re.search(r"\b(error|fail|exception|traceback)\b", result, re.I))


def no_error(result: str) -> bool:
    return not contains_error(result)


def json_ok(result: str) -> bool:
    """Pass if upstream returned valid JSON."""
    try:
        json.loads(result)
        return True
    except (json.JSONDecodeError, ValueError):
        return False


# Registry by name — used when loading saved workflow templates.
REGISTRY: dict[str, callable] = {
    "always": always,
    "not_empty": not_empty,
    "confidence_high": confidence_high,
    "confidence_low": confidence_low,
    "contains_error": contains_error,
    "no_error": no_error,
    "json_ok": json_ok,
}


def by_name(name: str) -> callable:
    if name not in REGISTRY:
        raise KeyError(f"Unknown condition: {name!r}. Available: {list(REGISTRY)}")
    return REGISTRY[name]
