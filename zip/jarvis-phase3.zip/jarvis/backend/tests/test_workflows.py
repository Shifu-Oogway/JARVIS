"""Phase 3: DAG model, executor, conditions, templates — all offline."""
from __future__ import annotations

import asyncio
import pytest

from app.domain.enums import AgentRole, TaskStatus
from app.workflows.conditions import confidence_high, confidence_low, no_error
from app.workflows.dag import WorkflowDAG
from app.workflows.executor import DAGExecutor, _parse_dynamic
from app.workflows.registry import template_registry


# ── DAG model ────────────────────────────────────────────────────────────────

def test_dag_ready_roots():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    b = dag.add_node("B", AgentRole.ANALYSIS)
    dag.add_edge(a.id, b.id)
    ready = dag.ready_nodes()
    assert len(ready) == 1 and ready[0].id == a.id


def test_dag_ready_after_upstream():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    b = dag.add_node("B", AgentRole.ANALYSIS)
    dag.add_edge(a.id, b.id)
    a.status = TaskStatus.SUCCEEDED
    a.result = "done"
    ready = dag.ready_nodes()
    assert any(n.id == b.id for n in ready)


def test_dag_cycle_detection():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    b = dag.add_node("B", AgentRole.ANALYSIS)
    dag.add_edge(a.id, b.id)
    dag.add_edge(b.id, a.id)   # creates cycle
    with pytest.raises(ValueError, match="Cycle"):
        dag.validate()


def test_dag_conditional_edge_blocks():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    b = dag.add_node("B", AgentRole.EXECUTIVE)
    dag.add_edge(a.id, b.id, condition=confidence_high)
    a.status = TaskStatus.SUCCEEDED
    a.result = "confidence: 0.45"   # below threshold → b should NOT be ready
    assert dag.ready_nodes() == []


def test_dag_conditional_edge_passes():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    b = dag.add_node("B", AgentRole.EXECUTIVE)
    dag.add_edge(a.id, b.id, condition=confidence_high)
    a.status = TaskStatus.SUCCEEDED
    a.result = "confidence: 0.95"
    assert any(n.id == b.id for n in dag.ready_nodes())


def test_dag_dynamic_inject():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    from app.workflows.dag import DAGNode, DAGEdge
    n = DAGNode(id="dyn-1", objective="sub", role=AgentRole.ANALYSIS)
    dag.inject_nodes([n], [DAGEdge(src=a.id, dst="dyn-1")])
    assert "dyn-1" in dag.nodes
    assert any(e.dst == "dyn-1" for e in dag.edges)


def test_dag_is_complete():
    dag = WorkflowDAG()
    a = dag.add_node("A", AgentRole.RESEARCH)
    assert not dag.is_complete()
    a.status = TaskStatus.SUCCEEDED
    assert dag.is_complete()


# ── Conditions ────────────────────────────────────────────────────────────────

def test_conditions():
    assert confidence_high("The result has confidence: 0.92 overall.") is True
    assert confidence_high("confidence: 0.50") is False
    assert confidence_low("confidence: 0.50") is True
    assert no_error("Everything worked fine") is True
    assert no_error("An error occurred: KeyError") is False


# ── Dynamic sub-plan parser ───────────────────────────────────────────────────

def test_parse_dynamic_valid():
    result = '{"subtasks": [{"objective": "Research X", "role": "research"}, {"objective": "Analyse", "role": "analysis"}]}'
    nodes, edges = _parse_dynamic(result, "parent-1")
    assert len(nodes) == 2
    assert nodes[0].role == AgentRole.RESEARCH
    assert edges[0].src == "parent-1"      # first child depends on parent
    assert edges[1].src == nodes[0].id     # second child depends on first


def test_parse_dynamic_not_json():
    nodes, edges = _parse_dynamic("plain text result", "p")
    assert nodes == [] and edges == []


def test_parse_dynamic_no_subtasks():
    nodes, edges = _parse_dynamic('{"other": "data"}', "p")
    assert nodes == []


# ── Executor (mock agents) ────────────────────────────────────────────────────

class _MockAgents:
    """Stand-in AgentRegistry: all agents return 'mock result'."""
    class _Agent:
        async def run(self, objective, context=""):
            await asyncio.sleep(0)
            return f"mock result for: {objective}"
    def get(self, role):
        return self._Agent()


@pytest.mark.asyncio
async def test_executor_simple_dag():
    dag = WorkflowDAG()
    a = dag.add_node("Task A", AgentRole.RESEARCH)
    b = dag.add_node("Task B", AgentRole.ANALYSIS)
    dag.add_edge(a.id, b.id)
    ex = DAGExecutor(_MockAgents())
    result = await ex.execute(dag)
    assert result.nodes[a.id].status == TaskStatus.SUCCEEDED
    assert result.nodes[b.id].status == TaskStatus.SUCCEEDED
    assert result.is_complete()


@pytest.mark.asyncio
async def test_executor_parallel_dag():
    dag = WorkflowDAG()
    a = dag.add_node("Parallel A", AgentRole.RESEARCH)
    b = dag.add_node("Parallel B", AgentRole.RESEARCH)
    c = dag.add_node("Merge", AgentRole.EXECUTIVE)
    dag.add_edge(a.id, c.id)
    dag.add_edge(b.id, c.id)
    ex = DAGExecutor(_MockAgents())
    result = await ex.execute(dag)
    assert all(n.status == TaskStatus.SUCCEEDED for n in result.nodes.values())


@pytest.mark.asyncio
async def test_executor_retry_on_failure():
    call_count = [0]
    class _FlakyAgent:
        async def run(self, objective, context=""):
            call_count[0] += 1
            if call_count[0] < 3:
                raise RuntimeError("transient error")
            return "success after retries"
    class _FlakyAgents:
        def get(self, role): return _FlakyAgent()

    dag = WorkflowDAG()
    n = dag.add_node("Flaky task", AgentRole.RESEARCH, max_retries=3)
    ex = DAGExecutor(_FlakyAgents())
    result = await ex.execute(dag)
    assert result.nodes[n.id].status == TaskStatus.SUCCEEDED
    assert call_count[0] == 3


@pytest.mark.asyncio
async def test_executor_dead_letter_on_exhaustion():
    class _FailingAgents:
        class _Agent:
            async def run(self, objective, context=""):
                raise RuntimeError("always fails")
        def get(self, role): return self._Agent()

    dag = WorkflowDAG()
    n = dag.add_node("Always fails", AgentRole.RESEARCH, max_retries=1)
    ex = DAGExecutor(_FailingAgents())
    result = await ex.execute(dag)
    assert result.nodes[n.id].status == TaskStatus.FAILED
    assert len(result.dead_letters) == 1
    assert result.dead_letters[0]["attempts"] == 2   # 1 initial + 1 retry


@pytest.mark.asyncio
async def test_executor_timeout_retries():
    class _SlowAgents:
        class _Agent:
            async def run(self, objective, context=""):
                await asyncio.sleep(10)   # deliberately slow
                return "never"
        def get(self, role): return self._Agent()

    dag = WorkflowDAG()
    n = dag.add_node("Slow task", AgentRole.RESEARCH, max_retries=0, timeout_s=0.05)
    ex = DAGExecutor(_SlowAgents())
    result = await ex.execute(dag)
    assert result.nodes[n.id].status == TaskStatus.FAILED
    assert "Timeout" in result.nodes[n.id].error


# ── Templates ─────────────────────────────────────────────────────────────────

def test_templates_build_and_validate():
    for name in template_registry.list():
        dag = template_registry.build(name)
        dag.validate()   # must be cycle-free
        assert len(dag.nodes) > 0
