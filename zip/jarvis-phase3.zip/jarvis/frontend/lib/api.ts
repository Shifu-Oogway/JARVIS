const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type AgentView = {
  role: string;
  status: string;
  current_task: string | null;
  queue_depth: number;
  model: string;
  metrics: { invocations: number; failures: number; avg_latency_s: number };
};

export type ChatResult = {
  plan_id: string;
  answer: string;
  tasks: { id: string; role: string; objective: string; status: string; result: string | null }[];
};

export type JarvisEvent = { kind: string; payload: Record<string, unknown>; ts: string };

export async function getAgents(): Promise<AgentView[]> {
  const r = await fetch(`${BASE}/agents`, { cache: "no-store" });
  if (!r.ok) throw new Error("agents unavailable");
  return r.json();
}

export async function sendChat(message: string): Promise<ChatResult> {
  const r = await fetch(`${BASE}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });
  if (!r.ok) throw new Error("chat failed");
  return r.json();
}

export function eventsUrl(): string {
  return `${BASE.replace(/^http/, "ws")}/ws/events`;
}

export type MemoryOverview = {
  counts: Record<string, number>;
  recent: { id: string; layer: string; preview: string; vault_path: string | null }[];
};

export async function getMemory(): Promise<MemoryOverview> {
  const r = await fetch(`${BASE}/memory`, { cache: "no-store" });
  if (!r.ok) throw new Error("memory unavailable");
  return r.json();
}

export async function getVaultTree(): Promise<Record<string, string[]>> {
  const r = await fetch(`${BASE}/vault/tree`, { cache: "no-store" });
  if (!r.ok) throw new Error("vault unavailable");
  return r.json();
}

export type DAGNodeView = {
  id: string; objective: string; role: string; status: string;
  result: string | null; error: string | null; attempt: number;
  started_at: string | null; finished_at: string | null;
};
export type DAGEdgeView = { src: string; dst: string; has_condition: boolean };
export type WorkflowView = {
  id: string; name: string; nodes: DAGNodeView[]; edges: DAGEdgeView[];
  dead_letters: Record<string, unknown>[]; complete: boolean; created_at: string;
};
export type WorkflowSummary = {
  id: string; name: string; nodes_total: number; nodes_done: number;
  nodes_failed: number; dead_letters: number; complete: boolean; created_at: string;
};

export async function getWorkflows(): Promise<WorkflowSummary[]> {
  const r = await fetch(`${BASE}/workflows`, { cache: "no-store" });
  if (!r.ok) throw new Error("workflows unavailable");
  return r.json();
}

export async function getWorkflow(id: string): Promise<WorkflowView> {
  const r = await fetch(`${BASE}/workflows/${id}`, { cache: "no-store" });
  if (!r.ok) throw new Error("workflow not found");
  return r.json();
}

export async function createWorkflow(body: Record<string, unknown>): Promise<{ id: string }> {
  const r = await fetch(`${BASE}/workflows`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("create failed");
  return r.json();
}

export async function getTemplates(): Promise<string[]> {
  const r = await fetch(`${BASE}/workflows/templates`, { cache: "no-store" });
  if (!r.ok) return [];
  return r.json();
}
