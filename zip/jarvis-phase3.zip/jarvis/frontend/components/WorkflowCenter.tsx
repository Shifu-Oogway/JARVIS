"use client";

import { useEffect, useState } from "react";
import {
  createWorkflow, getTemplates, getWorkflow, getWorkflows,
  type DAGNodeView, type WorkflowSummary, type WorkflowView,
} from "@/lib/api";

// ── status colours ────────────────────────────────────────────────────────────
const STATUS_COLOR: Record<string, string> = {
  succeeded: "text-live",   pending: "text-muted",
  running:   "text-warn",   failed:  "text-bad",
  cancelled: "text-muted",
};

function NodeBadge({ node }: { node: DAGNodeView }) {
  const col = STATUS_COLOR[node.status] ?? "text-muted";
  return (
    <div className={`rounded border border-edge px-2 py-1 text-[10px] font-mono ${col}`}
         title={node.error ?? node.result ?? node.objective}>
      <span className="text-surge mr-1">{node.role}</span>
      {node.objective.slice(0, 28)}{node.objective.length > 28 ? "…" : ""}
      <span className={`ml-1 ${col}`}>[{node.status}]</span>
      {node.attempt > 0 && <span className="ml-1 text-warn">×{node.attempt + 1}</span>}
    </div>
  );
}

function DAGGraph({ wf }: { wf: WorkflowView }) {
  // Simple topological column layout — no d3 needed.
  // Build depth map for each node.
  const depth: Record<string, number> = {};
  const adj: Record<string, string[]> = {};
  wf.nodes.forEach((n) => { depth[n.id] = 0; adj[n.id] = []; });
  wf.edges.forEach((e) => adj[e.src]?.push(e.dst));

  let changed = true;
  while (changed) {
    changed = false;
    wf.edges.forEach((e) => {
      const d = (depth[e.src] ?? 0) + 1;
      if (d > (depth[e.dst] ?? 0)) { depth[e.dst] = d; changed = true; }
    });
  }

  const maxDepth = Math.max(0, ...Object.values(depth));
  const columns: DAGNodeView[][] = Array.from({ length: maxDepth + 1 }, () => []);
  wf.nodes.forEach((n) => columns[depth[n.id] ?? 0].push(n));

  return (
    <div className="flex gap-3 overflow-x-auto py-2">
      {columns.map((col, ci) => (
        <div key={ci} className="flex flex-col gap-2 min-w-[160px]">
          {col.map((n) => <NodeBadge key={n.id} node={n} />)}
        </div>
      ))}
      {wf.nodes.length === 0 && <p className="text-xs text-muted">No nodes.</p>}
    </div>
  );
}

// ── main component ─────────────────────────────────────────────────────────────
export function WorkflowCenter() {
  const [summaries, setSummaries] = useState<WorkflowSummary[]>([]);
  const [selected, setSelected] = useState<WorkflowView | null>(null);
  const [templates, setTemplates] = useState<string[]>([]);
  const [tpl, setTpl] = useState("");
  const [topic, setTopic] = useState("");
  const [launching, setLaunching] = useState(false);

  useEffect(() => {
    let alive = true;
    getTemplates().then((t) => alive && (setTemplates(t), setTpl(t[0] ?? "")));
    const tick = () =>
      getWorkflows().then((w) => { if (!alive) return; setSummaries(w); });
    tick();
    const id = setInterval(tick, 3000);
    return () => { alive = false; clearInterval(id); };
  }, []);

  useEffect(() => {
    if (!selected) return;
    let alive = true;
    const tick = () =>
      getWorkflow(selected.id).then((w) => alive && setSelected(w));
    const id = setInterval(tick, 1500);
    return () => { alive = false; clearInterval(id); };
  }, [selected?.id]);

  async function launch() {
    if (!tpl || launching) return;
    setLaunching(true);
    try {
      await createWorkflow({ template: tpl, params: { topic }, start: true });
      setSummaries(await getWorkflows());
    } finally { setLaunching(false); }
  }

  const progress = (s: WorkflowSummary) =>
    s.nodes_total ? Math.round((s.nodes_done / s.nodes_total) * 100) : 0;

  return (
    <div className="p-4 space-y-4">
      {/* launch bar */}
      <div className="flex gap-2 flex-wrap">
        <select
          value={tpl}
          onChange={(e) => setTpl(e.target.value)}
          className="rounded-md border border-edge bg-ink px-2 py-1.5 text-xs text-text outline-none focus:border-surge"
        >
          {templates.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <input
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="topic (optional)"
          className="rounded-md border border-edge bg-ink px-2 py-1.5 text-xs text-text outline-none focus:border-surge w-40"
        />
        <button
          onClick={launch} disabled={launching || !tpl}
          className="rounded-md border border-edge px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest text-surge hover:border-surge disabled:opacity-40"
        >
          {launching ? "Starting…" : "Launch"}
        </button>
      </div>

      {/* workflow list */}
      <div className="space-y-2 max-h-48 overflow-auto">
        {summaries.length === 0 && <p className="text-xs text-muted">No workflows yet.</p>}
        {summaries.map((s) => (
          <div
            key={s.id}
            onClick={() => getWorkflow(s.id).then(setSelected)}
            className={`cursor-pointer rounded border p-2 text-xs transition-colors ${
              selected?.id === s.id ? "border-surge bg-ink" : "border-edge hover:border-muted"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-text truncate max-w-[200px]" title={s.name}>{s.name}</span>
              <span className={s.complete ? "text-live" : s.nodes_failed ? "text-bad" : "text-warn"}>
                {s.complete ? "done" : s.nodes_failed ? "partial" : "running"}
              </span>
            </div>
            {/* mini progress bar */}
            <div className="mt-1.5 h-0.5 w-full rounded bg-edge">
              <div
                className="h-0.5 rounded bg-live transition-all"
                style={{ width: `${progress(s)}%` }}
              />
            </div>
            <div className="mt-1 flex gap-3 text-[10px] text-muted">
              <span>{s.nodes_done}/{s.nodes_total} nodes</span>
              {s.dead_letters > 0 && <span className="text-bad">⚠ {s.dead_letters} DLQ</span>}
            </div>
          </div>
        ))}
      </div>

      {/* DAG graph for selected workflow */}
      {selected && (
        <div>
          <div className="eyebrow mb-2">{selected.name}</div>
          <DAGGraph wf={selected} />
          {selected.dead_letters.length > 0 && (
            <div className="mt-2 rounded border border-bad/40 bg-bad/5 p-2 text-[10px] text-bad">
              Dead-letter queue: {selected.dead_letters.length} exhausted node(s)
            </div>
          )}
        </div>
      )}
    </div>
  );
}
