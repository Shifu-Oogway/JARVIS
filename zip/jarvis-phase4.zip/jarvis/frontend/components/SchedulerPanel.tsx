"use client";

import { useEffect, useRef, useState } from "react";

const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

type Job = {
  id: string; name: string; kind: string; schedule: string; request: string;
  enabled: boolean; run_count: number; last_run_at: string | null;
  next_run_at: string | null; last_status: string | null; last_result: string | null;
  tags: string[];
};

const KIND_LABEL: Record<string, string> = {
  cron: "Cron", interval: "Interval", once: "Once", event: "Event",
};
const STATUS_COL: Record<string, string> = {
  succeeded: "text-live", failed: "text-bad", running: "text-warn",
};

function fmtDt(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit" });
}

async function api(path: string, opts?: RequestInit) {
  const r = await fetch(`${BASE}${path}`, opts);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

export function SchedulerPanel() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selected, setSelected] = useState<Job | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: "", kind: "cron", schedule: "0 7 * * *", request: "", tags: "" });
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = () =>
    fetch(`${BASE}/scheduler/jobs`, { cache: "no-store" })
      .then((r) => r.json()).then(setJobs).catch(() => {});

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 4000);
    return () => clearInterval(id);
  }, []);

  async function act(path: string, method = "POST") {
    setBusy(path);
    try { await api(path, { method }); await refresh(); } catch { }
    finally { setBusy(null); }
  }

  async function submit() {
    if (!form.name || !form.request) return;
    setBusy("create");
    try {
      await api("/scheduler/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean) }),
      });
      setCreating(false);
      setForm({ name: "", kind: "cron", schedule: "0 7 * * *", request: "", tags: "" });
      await refresh();
    } catch { } finally { setBusy(null); }
  }

  return (
    <div className="p-4 space-y-4">
      {/* header + new button */}
      <div className="flex items-center justify-between">
        <span className="eyebrow">{jobs.length} job{jobs.length !== 1 ? "s" : ""}</span>
        <button
          onClick={() => setCreating((v) => !v)}
          className="rounded-md border border-edge px-2 py-1 font-mono text-[11px] uppercase tracking-widest text-surge hover:border-surge"
        >
          {creating ? "Cancel" : "+ New job"}
        </button>
      </div>

      {/* create form */}
      {creating && (
        <div className="rounded-md border border-edge bg-ink/60 p-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="Job name" className="input-sm col-span-2" />
            <select value={form.kind} onChange={(e) => setForm((f) => ({ ...f, kind: e.target.value }))}
              className="input-sm">
              {Object.entries(KIND_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <input value={form.schedule} onChange={(e) => setForm((f) => ({ ...f, schedule: e.target.value }))}
              placeholder={form.kind === "cron" ? "0 7 * * *" : form.kind === "interval" ? "3600" : form.kind === "once" ? "2026-07-01T09:00:00Z" : "event.kind"}
              className="input-sm" />
            <input value={form.request} onChange={(e) => setForm((f) => ({ ...f, request: e.target.value }))}
              placeholder="JARVIS directive…" className="input-sm col-span-2" />
            <input value={form.tags} onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))}
              placeholder="tags (comma-separated)" className="input-sm col-span-2" />
          </div>
          <button onClick={submit} disabled={busy === "create" || !form.name || !form.request}
            className="rounded-md border border-edge px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-live hover:border-live disabled:opacity-40">
            {busy === "create" ? "Creating…" : "Create"}
          </button>
        </div>
      )}

      {/* job list */}
      <div className="space-y-2 max-h-72 overflow-auto">
        {jobs.length === 0 && <p className="text-xs text-muted">No scheduled jobs.</p>}
        {jobs.map((j) => (
          <div key={j.id}
            onClick={() => setSelected((s) => s?.id === j.id ? null : j)}
            className={`cursor-pointer rounded border p-2 text-xs transition-colors ${
              selected?.id === j.id ? "border-surge" : "border-edge hover:border-muted"
            }`}
          >
            {/* row 1: name + kind + status dot */}
            <div className="flex items-center gap-2">
              <span className={`h-1.5 w-1.5 rounded-full ${j.enabled ? "bg-live" : "bg-muted"}`} />
              <span className="font-mono text-text font-medium">{j.name}</span>
              <span className="ml-auto rounded bg-edge px-1.5 py-0.5 font-mono text-[10px] text-muted">
                {KIND_LABEL[j.kind]}
              </span>
            </div>

            {/* row 2: schedule + next run */}
            <div className="mt-1 flex gap-3 text-[10px] text-muted font-mono">
              <span className="text-surge">{j.schedule}</span>
              <span>next {fmtDt(j.next_run_at)}</span>
              <span>×{j.run_count}</span>
              {j.last_status && (
                <span className={STATUS_COL[j.last_status] ?? "text-muted"}>{j.last_status}</span>
              )}
            </div>

            {/* expanded controls */}
            {selected?.id === j.id && (
              <div className="mt-2 space-y-2" onClick={(e) => e.stopPropagation()}>
                {j.last_result && (
                  <p className="rounded bg-ink/80 p-2 font-mono text-[10px] text-muted line-clamp-3">
                    {j.last_result}
                  </p>
                )}
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: "▶ Run now", path: `/scheduler/jobs/${j.id}/run` },
                    j.enabled
                      ? { label: "⏸ Pause", path: `/scheduler/jobs/${j.id}/pause` }
                      : { label: "▶ Resume", path: `/scheduler/jobs/${j.id}/resume` },
                    { label: "✕ Delete", path: `/scheduler/jobs/${j.id}`, method: "DELETE" },
                  ].map(({ label, path, method }) => (
                    <button key={label}
                      onClick={() => { act(path, method); if (method === "DELETE") setSelected(null); }}
                      disabled={busy === path}
                      className="rounded border border-edge px-2 py-0.5 font-mono text-[10px] text-muted hover:border-surge hover:text-surge disabled:opacity-40"
                    >
                      {busy === path ? "…" : label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
