"""Scheduler engine — the async background loop.

Responsibilities
────────────────
• Tick loop (1s resolution) — checks all cron/interval/once jobs for due-ness.
• Event listener — subscribes to the event bus; fires 'event' kind jobs when
  their configured event kind matches an incoming event.
• Job execution — calls JarvisCore.handle() and optionally submits a workflow
  DAG; records the run in the store; updates next_run_at.
• Graceful shutdown — waits for in-progress runs before exiting.

JarvisCore and DAGExecutor are injected at start() time to avoid circular imports.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from app.core.events import event_bus
from app.core.logging import get_logger
from app.scheduler.job import JobKind, JobRun, ScheduledJob
from app.scheduler.store import JobStore

log = get_logger("scheduler.engine")

_TICK_S = 1.0          # polling resolution
_MAX_PARALLEL = 4      # max concurrent job executions


class SchedulerEngine:
    def __init__(self, store: JobStore) -> None:
        self._store = store
        self._core = None          # set by start()
        self._dag_executor = None  # set by start()
        self._sem = asyncio.Semaphore(_MAX_PARALLEL)
        self._tasks: set[asyncio.Task] = set()
        self._running = False
        self._tick_task: asyncio.Task | None = None
        self._event_task: asyncio.Task | None = None

    # ── lifecycle ─────────────────────────────────────────────────────────────
    async def start(self, core, dag_executor=None) -> None:
        self._core = core
        self._dag_executor = dag_executor
        self._running = True
        await self._store.hydrate()
        # recompute next_run for any job that doesn't have one
        for job in self._store.all():
            if job.next_run_at is None and job.kind != JobKind.EVENT:
                job.next_run_at = job.compute_next_run()
                await self._store.save(job)
        self._tick_task  = asyncio.create_task(self._tick_loop(), name="sched-tick")
        self._event_task = asyncio.create_task(self._event_loop(), name="sched-events")
        log.info("scheduler_started", jobs=len(self._store.all()))

    async def stop(self) -> None:
        self._running = False
        for t in [self._tick_task, self._event_task]:
            if t:
                t.cancel()
        # wait for in-flight job tasks
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        log.info("scheduler_stopped")

    # ── tick loop ─────────────────────────────────────────────────────────────
    async def _tick_loop(self) -> None:
        while self._running:
            now = datetime.now(timezone.utc)
            for job in self._store.all():
                if job.is_due(now):
                    t = asyncio.create_task(self._run_job(job), name=f"job-{job.id[:8]}")
                    self._tasks.add(t)
                    t.add_done_callback(self._tasks.discard)
            await asyncio.sleep(_TICK_S)

    # ── event listener ────────────────────────────────────────────────────────
    async def _event_loop(self) -> None:
        try:
            async for event in event_bus.subscribe():
                if not self._running:
                    break
                kind = event.get("kind", "")
                for job in self._store.all():
                    if (job.kind == JobKind.EVENT
                            and job.enabled
                            and job.schedule == kind):
                        t = asyncio.create_task(
                            self._run_job(job, trigger=f"event:{kind}"),
                            name=f"job-evt-{job.id[:8]}"
                        )
                        self._tasks.add(t)
                        t.add_done_callback(self._tasks.discard)
        except asyncio.CancelledError:
            pass

    # ── job runner ────────────────────────────────────────────────────────────
    async def _run_job(self, job: ScheduledJob, trigger: str = "scheduled") -> None:
        async with self._sem:
            now = datetime.now(timezone.utc)
            run = JobRun(job_id=job.id, started_at=now)

            job.run_count += 1
            job.last_run_at = now
            job.last_status = "running"

            from app.core.events import event_bus as _eb
            await _eb.publish("job.started", {
                "job_id": job.id, "name": job.name, "trigger": trigger
            })
            log.info("job_started", id=job.id, name=job.name, trigger=trigger)

            try:
                if self._core is None:
                    raise RuntimeError("SchedulerEngine not connected to JarvisCore")
                result_dict = await self._core.handle(job.request)
                answer = result_dict.get("answer", "")
                run.result  = answer
                run.status  = "succeeded"
                run.finished_at = datetime.now(timezone.utc)
                job.last_status = "succeeded"
                job.last_result = answer[:500]
                await _eb.publish("job.succeeded", {"job_id": job.id, "name": job.name})
                log.info("job_succeeded", id=job.id, name=job.name)

            except Exception as exc:   # noqa: BLE001
                run.error       = str(exc)
                run.status      = "failed"
                run.finished_at = datetime.now(timezone.utc)
                job.last_status = "failed"
                job.last_result = str(exc)[:500]
                await _eb.publish("job.failed", {
                    "job_id": job.id, "name": job.name, "error": str(exc)
                })
                log.warning("job_failed", id=job.id, name=job.name, error=str(exc))

            finally:
                await self._store.record_run(run)

                # advance next_run
                if job.kind == JobKind.ONCE:
                    job.enabled = False      # fire-once → auto-disable
                    job.next_run_at = None
                elif job.kind != JobKind.EVENT:
                    job.next_run_at = job.compute_next_run(after=datetime.now(timezone.utc))

                await self._store.save(job)

    # ── management API (called by route handlers) ─────────────────────────────
    async def create_job(self, job: ScheduledJob) -> ScheduledJob:
        if job.kind != JobKind.EVENT:
            job.next_run_at = job.compute_next_run()
        await self._store.save(job)
        log.info("job_created", id=job.id, name=job.name, kind=job.kind)
        return job

    async def update_job(self, job_id: str, patch: dict) -> ScheduledJob:
        job = self._store.get(job_id)
        if job is None:
            raise KeyError(job_id)
        for k, v in patch.items():
            if hasattr(job, k):
                setattr(job, k, v)
        # recompute next_run if schedule changed or job re-enabled
        if "schedule" in patch or "enabled" in patch:
            if job.kind != JobKind.EVENT:
                job.next_run_at = job.compute_next_run()
        await self._store.save(job)
        return job

    async def delete_job(self, job_id: str) -> bool:
        return await self._store.delete(job_id)

    async def trigger_now(self, job_id: str) -> None:
        job = self._store.get(job_id)
        if job is None:
            raise KeyError(job_id)
        t = asyncio.create_task(
            self._run_job(job, trigger="manual"),
            name=f"job-manual-{job_id[:8]}"
        )
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)
