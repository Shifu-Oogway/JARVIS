"""Scheduler job store — Redis-backed with DB fallback.

Redis  : fast in-process store; all live jobs kept as hash fields.
DB     : (via SQLAlchemy model ScheduledJob) durable, written on every mutation.
         On startup the engine hydrates from DB, so jobs survive pod restarts.

The store is the *only* place that writes jobs.  The engine reads from the store.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import redis.asyncio as aioredis

from app.core.config import get_settings
from app.core.logging import get_logger
from app.scheduler.job import JobRun, ScheduledJob

log = get_logger("scheduler.store")

_JOBS_KEY   = "jarvis:scheduler:jobs"     # Redis hash  field=job_id  value=json
_RUNS_KEY   = "jarvis:scheduler:runs:{}"  # Redis list  per job_id    (recent runs)
_MAX_RUNS   = 50                           # history kept per job in Redis


class JobStore:
    def __init__(self) -> None:
        self._redis: aioredis.Redis | None = None
        self._local: dict[str, ScheduledJob] = {}   # in-memory fallback

    async def _r(self) -> aioredis.Redis | None:
        if self._redis is not None:
            return self._redis
        try:
            r = aioredis.from_url(get_settings().redis_url, decode_responses=True)
            await r.ping()
            self._redis = r
        except Exception:   # noqa: BLE001
            self._redis = None
        return self._redis

    # ── CRUD ─────────────────────────────────────────────────────────────────
    async def save(self, job: ScheduledJob) -> None:
        self._local[job.id] = job
        r = await self._r()
        if r:
            try:
                await r.hset(_JOBS_KEY, job.id, job.to_json())
            except Exception as exc:   # noqa: BLE001
                log.warning("redis_save_failed", error=str(exc))

    async def delete(self, job_id: str) -> bool:
        existed = job_id in self._local
        self._local.pop(job_id, None)
        r = await self._r()
        if r:
            await r.hdel(_JOBS_KEY, job_id)
        return existed

    def get(self, job_id: str) -> ScheduledJob | None:
        return self._local.get(job_id)

    def all(self) -> list[ScheduledJob]:
        return list(self._local.values())

    async def hydrate(self) -> int:
        """Load jobs from Redis on startup (DB persistence via SQLAlchemy is Phase 7)."""
        r = await self._r()
        if not r:
            return 0
        try:
            raw = await r.hgetall(_JOBS_KEY)
            for jid, jjson in raw.items():
                try:
                    job = ScheduledJob.from_dict(json.loads(jjson))
                    self._local[job.id] = job
                except Exception as exc:   # noqa: BLE001
                    log.warning("hydrate_job_failed", id=jid, error=str(exc))
            log.info("scheduler_hydrated", count=len(self._local))
            return len(self._local)
        except Exception as exc:   # noqa: BLE001
            log.warning("hydrate_failed", error=str(exc))
            return 0

    # ── Run history ───────────────────────────────────────────────────────────
    async def record_run(self, run: JobRun) -> None:
        job = self._local.get(run.job_id)
        if job:
            job.history.append(run)
            job.history = job.history[-_MAX_RUNS:]
        r = await self._r()
        if r:
            key = _RUNS_KEY.format(run.job_id)
            try:
                await r.lpush(key, json.dumps(run.to_dict()))
                await r.ltrim(key, 0, _MAX_RUNS - 1)
            except Exception:   # noqa: BLE001
                pass

    async def get_runs(self, job_id: str, n: int = 20) -> list[dict]:
        job = self._local.get(job_id)
        if job and job.history:
            return [r.to_dict() for r in reversed(job.history[-n:])]
        r = await self._r()
        if not r:
            return []
        raw = await r.lrange(_RUNS_KEY.format(job_id), 0, n - 1)
        return [json.loads(x) for x in raw]
