"""Scheduler job domain model.

Four job kinds:
  cron     — standard 5-field cron expression  "0 7 * * *"
  interval — every N seconds                   "3600"
  once     — fire once at an ISO-8601 datetime  "2026-07-01T09:00:00Z"
  event    — fire when a named event arrives    "request.completed"

All four support: enabled/disabled, run history, next-run tracking.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from uuid import uuid4

from croniter import croniter


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uid() -> str:
    return str(uuid4())


class JobKind(StrEnum):
    CRON     = "cron"
    INTERVAL = "interval"
    ONCE     = "once"
    EVENT    = "event"


@dataclass
class JobRun:
    id: str = field(default_factory=_uid)
    job_id: str = ""
    started_at: datetime = field(default_factory=_now)
    finished_at: datetime | None = None
    status: str = "running"        # running | succeeded | failed
    result: str | None = None
    error: str | None = None

    def to_dict(self) -> dict:
        return {
            "id": self.id, "job_id": self.job_id,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "status": self.status,
            "result": (self.result or "")[:500],
            "error": self.error,
        }


@dataclass
class ScheduledJob:
    name: str
    kind: JobKind
    schedule: str    # cron expr / interval seconds / ISO datetime / event kind
    request: str     # the Jarvis Core directive to execute
    id: str = field(default_factory=_uid)
    enabled: bool = True
    run_count: int = 0
    last_run_at: datetime | None = None
    next_run_at: datetime | None = None
    last_status: str | None = None
    last_result: str | None = None
    created_at: datetime = field(default_factory=_now)
    tags: list[str] = field(default_factory=list)
    # runtime-only: recent run history (not persisted, populated from DB)
    history: list[JobRun] = field(default_factory=list)

    # ── next-run computation ─────────────────────────────────────────────
    def compute_next_run(self, after: datetime | None = None) -> datetime | None:
        base = after or _now()
        if self.kind == JobKind.CRON:
            try:
                return croniter(self.schedule, base).get_next(datetime).replace(tzinfo=timezone.utc)
            except Exception:
                return None
        elif self.kind == JobKind.INTERVAL:
            try:
                secs = int(self.schedule)
                return (self.last_run_at or base) + timedelta(seconds=secs)
            except ValueError:
                return None
        elif self.kind == JobKind.ONCE:
            try:
                dt = datetime.fromisoformat(self.schedule.replace("Z", "+00:00"))
                return dt if dt > base else None   # already past → no next run
            except ValueError:
                return None
        else:   # event — no clock-based next run
            return None

    def is_due(self, now: datetime | None = None) -> bool:
        if not self.enabled:
            return False
        now = now or _now()
        if self.kind == JobKind.EVENT:
            return False   # triggered by events, not the tick loop
        return self.next_run_at is not None and now >= self.next_run_at

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "kind": self.kind,
            "schedule": self.schedule, "request": self.request,
            "enabled": self.enabled, "run_count": self.run_count,
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "next_run_at": self.next_run_at.isoformat() if self.next_run_at else None,
            "last_status": self.last_status, "last_result": (self.last_result or "")[:300],
            "created_at": self.created_at.isoformat(), "tags": self.tags,
            "history": [r.to_dict() for r in self.history[-10:]],
        }

    # ── persistence helpers ──────────────────────────────────────────────
    def to_json(self) -> str:
        d = self.to_dict()
        d.pop("history", None)   # history stored separately
        return json.dumps(d)

    @classmethod
    def from_dict(cls, d: dict) -> "ScheduledJob":
        j = cls(
            name=d["name"], kind=JobKind(d["kind"]),
            schedule=d["schedule"], request=d["request"],
            id=d.get("id", _uid()), enabled=d.get("enabled", True),
            run_count=d.get("run_count", 0),
            last_status=d.get("last_status"),
            last_result=d.get("last_result"),
            tags=d.get("tags", []),
        )
        if d.get("last_run_at"):
            j.last_run_at = datetime.fromisoformat(d["last_run_at"])
        if d.get("next_run_at"):
            j.next_run_at = datetime.fromisoformat(d["next_run_at"])
        if d.get("created_at"):
            j.created_at = datetime.fromisoformat(d["created_at"])
        return j
