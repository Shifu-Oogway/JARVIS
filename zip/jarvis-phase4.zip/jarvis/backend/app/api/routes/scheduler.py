"""Scheduler REST API.

GET    /scheduler/jobs             list all jobs
POST   /scheduler/jobs             create a job
GET    /scheduler/jobs/{id}        job detail + recent runs
PATCH  /scheduler/jobs/{id}        update fields (schedule, enabled, name, request)
DELETE /scheduler/jobs/{id}        delete
POST   /scheduler/jobs/{id}/run    trigger immediately (ignores enabled flag)
POST   /scheduler/jobs/{id}/pause  set enabled=False
POST   /scheduler/jobs/{id}/resume set enabled=True + recompute next_run
GET    /scheduler/jobs/{id}/runs   run history
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request

from app.scheduler.engine import SchedulerEngine
from app.scheduler.job import JobKind, ScheduledJob

router = APIRouter(prefix="/scheduler", tags=["scheduler"])


def _get_engine(request: Request) -> SchedulerEngine:
    ex: SchedulerEngine | None = getattr(request.app.state, "scheduler", None)
    if ex is None:
        raise HTTPException(503, "Scheduler not initialised")
    return ex


# ── list ──────────────────────────────────────────────────────────────────────
@router.get("/jobs")
async def list_jobs(engine: SchedulerEngine = Depends(_get_engine)) -> list[dict]:
    return [j.to_dict() for j in engine._store.all()]


# ── create ────────────────────────────────────────────────────────────────────
@router.post("/jobs")
async def create_job(
    body: dict,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    """
    Required: name, kind, schedule, request
    Optional: tags, enabled
    Examples
    --------
    Cron:     {"name": "Daily brief", "kind": "cron",     "schedule": "0 7 * * *",    "request": "Generate daily AI news brief"}
    Interval: {"name": "Health ping", "kind": "interval", "schedule": "300",           "request": "Check JARVIS health"}
    Once:     {"name": "One-off",     "kind": "once",     "schedule": "2026-07-01T09:00:00Z", "request": "Summarise Q2"}
    Event:    {"name": "On complete", "kind": "event",    "schedule": "request.completed",    "request": "Archive last result"}
    """
    required = {"name", "kind", "schedule", "request"}
    missing = required - body.keys()
    if missing:
        raise HTTPException(422, f"Missing fields: {missing}")
    try:
        kind = JobKind(body["kind"])
    except ValueError:
        raise HTTPException(422, f"Invalid kind. Choose: {[k.value for k in JobKind]}")

    job = ScheduledJob(
        name=body["name"], kind=kind,
        schedule=body["schedule"], request=body["request"],
        enabled=body.get("enabled", True),
        tags=body.get("tags", []),
    )
    await engine.create_job(job)
    return job.to_dict()


# ── get ───────────────────────────────────────────────────────────────────────
@router.get("/jobs/{job_id}")
async def get_job(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    job = engine._store.get(job_id)
    if job is None:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return job.to_dict()


# ── update ────────────────────────────────────────────────────────────────────
@router.patch("/jobs/{job_id}")
async def update_job(
    job_id: str,
    body: dict,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    allowed = {"name", "schedule", "request", "enabled", "tags"}
    patch = {k: v for k, v in body.items() if k in allowed}
    if not patch:
        raise HTTPException(422, f"No updatable fields. Allowed: {allowed}")
    try:
        job = await engine.update_job(job_id, patch)
    except KeyError:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return job.to_dict()


# ── delete ────────────────────────────────────────────────────────────────────
@router.delete("/jobs/{job_id}")
async def delete_job(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    if not await engine.delete_job(job_id):
        raise HTTPException(404, f"Job {job_id!r} not found")
    return {"deleted": job_id}


# ── trigger now ───────────────────────────────────────────────────────────────
@router.post("/jobs/{job_id}/run")
async def run_now(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    try:
        await engine.trigger_now(job_id)
    except KeyError:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return {"triggered": job_id}


# ── pause / resume ────────────────────────────────────────────────────────────
@router.post("/jobs/{job_id}/pause")
async def pause_job(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    try:
        job = await engine.update_job(job_id, {"enabled": False})
    except KeyError:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return {"id": job_id, "enabled": job.enabled}


@router.post("/jobs/{job_id}/resume")
async def resume_job(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> dict:
    try:
        job = await engine.update_job(job_id, {"enabled": True})
    except KeyError:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return {"id": job_id, "enabled": job.enabled, "next_run_at": job.next_run_at.isoformat() if job.next_run_at else None}


# ── run history ───────────────────────────────────────────────────────────────
@router.get("/jobs/{job_id}/runs")
async def job_runs(
    job_id: str,
    engine: SchedulerEngine = Depends(_get_engine),
) -> list[dict]:
    if engine._store.get(job_id) is None:
        raise HTTPException(404, f"Job {job_id!r} not found")
    return await engine._store.get_runs(job_id, n=20)
