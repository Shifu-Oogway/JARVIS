"""Phase 4: job model, store, engine — all offline, no Redis/NIM required."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock

import pytest

from app.scheduler.job import JobKind, JobRun, ScheduledJob
from app.scheduler.store import JobStore
from app.scheduler.engine import SchedulerEngine


def _now():
    return datetime.now(timezone.utc)


# ── Job model ─────────────────────────────────────────────────────────────────

def test_cron_next_run():
    job = ScheduledJob(name="t", kind=JobKind.CRON,
                       schedule="0 9 * * *", request="test")
    nxt = job.compute_next_run(after=datetime(2026, 6, 15, 8, 0, tzinfo=timezone.utc))
    assert nxt is not None and nxt.hour == 9


def test_interval_next_run():
    job = ScheduledJob(name="t", kind=JobKind.INTERVAL,
                       schedule="60", request="test")
    base = _now()
    nxt = job.compute_next_run(after=base)
    assert abs((nxt - base).total_seconds() - 60) < 1


def test_once_past_returns_none():
    job = ScheduledJob(name="t", kind=JobKind.ONCE,
                       schedule="2020-01-01T00:00:00Z", request="test")
    assert job.compute_next_run() is None


def test_once_future_returns_dt():
    job = ScheduledJob(name="t", kind=JobKind.ONCE,
                       schedule="2099-01-01T00:00:00Z", request="test")
    nxt = job.compute_next_run()
    assert nxt is not None and nxt.year == 2099


def test_event_kind_never_due():
    job = ScheduledJob(name="t", kind=JobKind.EVENT,
                       schedule="request.completed", request="test")
    job.enabled = True
    assert job.is_due() is False


def test_is_due_true():
    job = ScheduledJob(name="t", kind=JobKind.INTERVAL,
                       schedule="60", request="test")
    job.next_run_at = _now() - timedelta(seconds=1)  # overdue
    assert job.is_due() is True


def test_is_due_disabled():
    job = ScheduledJob(name="t", kind=JobKind.INTERVAL,
                       schedule="60", request="test")
    job.next_run_at = _now() - timedelta(seconds=1)
    job.enabled = False
    assert job.is_due() is False


def test_roundtrip_serialisation():
    job = ScheduledJob(name="Daily brief", kind=JobKind.CRON,
                       schedule="0 7 * * *", request="Generate news brief",
                       tags=["ai", "daily"])
    restored = ScheduledJob.from_dict(job.to_dict())
    assert restored.name == job.name
    assert restored.kind == job.kind
    assert restored.tags == job.tags


# ── Job Store (in-memory only) ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_store_save_get_delete():
    store = JobStore()
    job = ScheduledJob(name="t", kind=JobKind.CRON,
                       schedule="* * * * *", request="test")
    await store.save(job)
    assert store.get(job.id) is job
    assert len(store.all()) == 1
    deleted = await store.delete(job.id)
    assert deleted is True
    assert store.get(job.id) is None


@pytest.mark.asyncio
async def test_store_record_run():
    store = JobStore()
    job = ScheduledJob(name="t", kind=JobKind.CRON,
                       schedule="* * * * *", request="test")
    await store.save(job)
    run = JobRun(job_id=job.id, status="succeeded", result="ok")
    await store.record_run(run)
    assert len(job.history) == 1
    runs = await store.get_runs(job.id)
    assert len(runs) == 1 and runs[0]["status"] == "succeeded"


# ── Engine ────────────────────────────────────────────────────────────────────

class _MockCore:
    def __init__(self, answer="mock"):
        self._answer = answer
        self.calls = []
    async def handle(self, request: str) -> dict:
        self.calls.append(request)
        return {"answer": self._answer, "tasks": []}


@pytest.mark.asyncio
async def test_engine_create_and_trigger():
    store = JobStore()
    engine = SchedulerEngine(store)
    core = _MockCore("the answer")
    await engine.start(core)   # starts background tasks (fine, they won't fire instantly)

    job = ScheduledJob(name="Manual", kind=JobKind.INTERVAL,
                       schedule="9999", request="Do something")
    await engine.create_job(job)
    assert store.get(job.id) is not None

    # trigger manually and wait for it to complete
    await engine.trigger_now(job.id)
    await asyncio.sleep(0.1)   # let the task run

    assert core.calls == ["Do something"]
    assert store.get(job.id).run_count == 1
    assert store.get(job.id).last_status == "succeeded"

    await engine.stop()


@pytest.mark.asyncio
async def test_engine_once_disables_after_run():
    store = JobStore()
    engine = SchedulerEngine(store)
    core = _MockCore()
    await engine.start(core)

    from datetime import timezone
    job = ScheduledJob(name="Once", kind=JobKind.ONCE,
                       schedule="2099-01-01T00:00:00Z", request="once job")
    await engine.create_job(job)

    await engine.trigger_now(job.id)
    await asyncio.sleep(0.1)

    saved = store.get(job.id)
    assert saved.enabled is False
    assert saved.next_run_at is None

    await engine.stop()


@pytest.mark.asyncio
async def test_engine_update_pause_resume():
    store = JobStore()
    engine = SchedulerEngine(store)
    core = _MockCore()
    await engine.start(core)

    job = ScheduledJob(name="p", kind=JobKind.CRON,
                       schedule="0 8 * * *", request="test")
    await engine.create_job(job)

    await engine.update_job(job.id, {"enabled": False})
    assert not store.get(job.id).enabled

    await engine.update_job(job.id, {"enabled": True})
    assert store.get(job.id).enabled
    assert store.get(job.id).next_run_at is not None   # recomputed

    await engine.stop()


@pytest.mark.asyncio
async def test_engine_failed_job_recorded():
    store = JobStore()
    engine = SchedulerEngine(store)

    class _FailingCore:
        async def handle(self, request):
            raise RuntimeError("NIM offline")

    await engine.start(_FailingCore())

    job = ScheduledJob(name="fail", kind=JobKind.INTERVAL,
                       schedule="9999", request="test")
    await engine.create_job(job)
    await engine.trigger_now(job.id)
    await asyncio.sleep(0.1)

    saved = store.get(job.id)
    assert saved.last_status == "failed"
    assert "NIM offline" in (saved.last_result or "")

    await engine.stop()
