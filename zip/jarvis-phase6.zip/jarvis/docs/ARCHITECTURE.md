# JARVIS — Architecture & Phase Roadmap

## Layered architecture (clean architecture)

```
Frontend (Next.js command center)
        │  REST + WebSocket
API Gateway (FastAPI routers, CORS, metrics middleware)
        │
Jarvis Core  ── executive layer: intent → decompose → assign → coordinate → synthesise
        │
Agent Orchestrator (AgentRegistry; parallel dependency-aware dispatch)
        │
Agent Runtime (BaseAgent: state · memory · tools · metrics · permissions)
        │
NVIDIA NIM Layer (Router → HealthMonitor → NIMClient pool; ModelRegistry by role)
        │
Memory Layer (DB-backed entries + Obsidian vault + rolling context engine*)
        │
Storage Layer (PostgreSQL · Redis · vault filesystem)
```
`*` = Phase 2. Each layer depends only on the layer below via an interface, so any
layer is independently replaceable (e.g. swap NIM for vLLM by reimplementing the NIM client).

## Request lifecycle

1. Client → `POST /chat` → `JarvisCore.handle`.
2. `decompose` asks the **planning** model for a JSON task list (heuristic fallback offline).
3. `execute` runs each dependency-ready wave **in parallel** (`asyncio.gather`), feeding prior
   results forward as context.
4. `synthesize` merges agent outputs via the **executive** model.
5. Every step emits an event on the Redis bus → `GET /ws/events` → dashboard Event Feed.

## Event architecture

Single Redis pub/sub channel `jarvis.events`. Event shape: `{ kind, payload, ts }`.
Kinds emitted today: `request.received/completed`, `task.started/succeeded/failed`,
`agent.started/succeeded/failed`, `nim_health_change`. Telemetry never blocks a request —
publish failures are swallowed and logged.

## Database schema (Phase 1)

| table            | purpose                                            |
|------------------|----------------------------------------------------|
| `agents`         | persisted agent state, model binding, metrics      |
| `workflows`      | a decomposed request                               |
| `tasks`          | tasks within a workflow (FK → workflows), w/ result|
| `memory_entries` | layered memory (active/working/long_term/archive)  |
| `scheduled_jobs` | cron-driven directives                             |
| `backups`        | backup catalogue (full/incremental)                |
| `audit_logs`     | who did what                                       |

## NIM routing

`ModelRegistry` maps each `AgentRole` → `ModelSpec(name, context_window, max_concurrency, capabilities)`.
`NIMRouter` keeps a pool of `NIMClient`s (one per endpoint URL), round-robins across the
**healthy** subset, and fails over on error by demoting the endpoint. `HealthMonitor` re-probes
every 30s. Everything is config-driven via `JARVIS_NIM_BASE_URL` + `JARVIS_NIM_EXTRA_ENDPOINTS`.

## Memory subsystem (Phase 2)

```
objective ──► ContextAssemblyEngine
                 1. semantic search   (MemoryStore + embeddings)   ◄─ layers: working/long_term/archive
                 2. graph expansion   (KnowledgeGraph neighbours)
                 3. rerank            (NeMo cross-encoder, optional)
                 4. budget packing    (active context first, then by score)
                 └─► ContextPackage ──► agent
request result ──► MemoryCompressor: distil ──► vault note ──► MemoryStore (long_term)
```

- **Vault = source of truth** (markdown files); `MemoryStore` is the in-process vector index
  hydrated from it on boot, so nothing is lost on restart.
- **Embeddings**: hosted `nv-embedqa-e5-v5` (1024-dim) when `JARVIS_NIM_API_KEY` is set; a
  deterministic hashing embedder otherwise, so semantic memory runs fully offline.
- **Reranking**: set `JARVIS_NIM_RERANK_URL` to a NeMo `/v1/ranking` endpoint to enable the
  cross-encoder; disabled → score ordering is used.
- New endpoints: `GET /memory`, `POST /memory/search`, `POST /memory/context`,
  `GET /vault/tree`, `GET /graph`.

## Voice subsystem (Phase 5)

```
mic ──► MediaRecorder (webm/opus) ──► POST /voice/stt ──► RivaSTT.transcribe()
                                                                  │
                                                          wake-word check
                                                                  │ (woke)
                                                          JarvisCore.handle()
                                                                  │
                                                          split_sentences(answer)
                                                                  │
                                              RivaTTS.synthesize() per sentence
                                                                  │
                                                       audio chunks ──► playback
```

- **REST path** (dashboard, any client that records a full utterance first):
  `POST /voice/stt` (multipart) → text, `POST /voice/tts` → wav bytes.
- **WebSocket path** (`/ws/voice`) — full session protocol: `config`, `audio_chunk`,
  `audio_end`, `interrupt` from the client; `transcript`, `wake_miss`, `thinking`,
  `response_text`, `audio_chunk` (sentence-by-sentence), `audio_end`, `interrupted`,
  `error` from the server. Continuous mode auto-closes an utterance via trailing-silence
  detection (`app/voice/audio.py`, pure-stdlib PCM16 energy check — no numpy).
- **Barge-in**: client sends `{"type": "interrupt"}`; the session cancels its in-flight
  `asyncio.Task` and returns to `listening` immediately. Stopping *audio playback* is the
  client's responsibility (stop the `<audio>` element / AudioContext source) — the backend
  can only stop sending further chunks.

## Ops subsystem (Phase 6)

```
BackupManager.create_backup(kind)
   ├─ vault     → tar.gz of changed/all .md files
   ├─ configs   → tar.gz of .env / docker-compose.yml / alembic.ini
   ├─ redis     → JSON dump of jarvis:* keys (logical, not RDB — portable)
   └─ postgres  → pg_dump output (skipped, not failed, if unreachable)
        │
        ▼ manifest.json (per-file sha256) + catalog.json (queryable history)
        ▼ BackupTarget.upload()  →  local / S3 / SFTP

RestoreManager.restore(backup_id, components, dry_run)
   1. validate()           — integrity check against manifest checksums
   2. safety snapshot       — create_backup(full) of CURRENT state first
   3. apply per component   — vault/configs auto-applied; postgres.sql surfaced
                               as a manual psql step (never auto-executed —
                               it's a destructive statement stream)

UpdateManager.apply_package(zip)
   1. extract → 2. verify Ed25519 signature → 3. verify per-file checksums
   → 4. safety backup → 5. run alembic migrations (if present)
   → 6. deploy files → 7. health check (import smoke test)
   → 8. switch traffic (no-op single-process; k8s rolling-update hook below)
   → 9. confirm
   Any failure from step 5 onward → automatic restore of the step-4 safety
   backup, recorded as status="rolled_back" with the failure reason.
```

- **Signing**: `scripts/sign_update.py keygen` produces an Ed25519 keypair *offline*.
  Only the public key (`JARVIS_UPDATE_PUBLIC_KEY`) ever touches the running server.
  `scripts/sign_update.py build` packages + signs a release directory into a `.zip`.
- **k8s rolling-update hook**: step 7 ("switch traffic") is a documented no-op in
  single-process dev mode. In Kubernetes, replace it with a Deployment image-tag
  bump + `kubectl rollout status` wait — the manifest/signature/integrity/backup/
  rollback machinery is identical either way.
- **Maintenance Agent** routes deterministic objectives ("backup now", "verify
  the last backup", "system health report") straight to tools instead of letting
  an LLM improvise what they mean; free-form objectives still fall back to the LLM.

## Phase roadmap

- **Phase 1 — Foundation (shipped):** clean-arch backend, NIM layer, agent framework,
  Jarvis Core, DB models + Alembic, event bus + WS feed, metrics, Docker infra, dashboard shell.
- **Phase 2 — Memory & Obsidian (shipped):** Obsidian vault adapter (markdown + YAML frontmatter,
  link/tag extraction), knowledge graph, NeMo Retriever embeddings (`nv-embedqa-e5-v5`) + reranker
  (`llama-3.2-nv-rerankqa-1b-v2`), 4-layer rolling context engine with the 7-step assembly pipeline,
  and Raw→Summary→Knowledge→Vault compression — wired into Jarvis Core.
- **Phase 3 — Workflow engine (shipped):** `WorkflowDAG` data model (nodes, conditional edges,
  topology/cycle validation, dynamic node injection), `DAGExecutor` (wave-based parallelism,
  per-node retries with exponential backoff, timeouts via `asyncio.wait_for`, Redis checkpointing,
  dead-letter queue), 8 named edge conditions (`confidence_high/low`, `no_error`, …),
  4 built-in workflow templates (`research-report`, `parallel-research`, `code-review`, …),
  REST + WebSocket API, live Workflow Center panel with DAG graph.
- **Phase 4 — Scheduler (shipped):** `ScheduledJob` model (4 kinds: cron, interval, once, event),
  `JobStore` (Redis-backed + in-memory fallback, run history), `SchedulerEngine` (async tick loop,
  event-bus listener, semaphore-bounded execution, graceful shutdown, auto-disable for once jobs),
  full REST API (list/create/get/update/delete/pause/resume/run-now/history), live Scheduler panel.
- **Phase 5 — Voice (shipped):** `STTProvider`/`TTSProvider` protocols + `RivaSTT`/`RivaTTS`
  (self-hosted Riva Speech NIM's HTTP API — `/v1/audio/transcriptions`, `/v1/audio/synthesize`,
  `/v1/audio/list_voices`), offline `NullSTT`/`NullTTS` fallback, transcript-based wake-word
  detection with fuzzy ASR-mishear matching, `VoiceSession` state machine (listening →
  transcribing → thinking → speaking, with barge-in cancellation), sentence-chunked TTS for
  pseudo-streaming playback, REST (`/voice/stt`, `/voice/tts`, `/voice/voices`) + WebSocket
  (`/ws/voice`) APIs, and a push-to-talk dashboard mic component.
  **Known constraint:** hosted build.nvidia.com speech models are gRPC-only (function-id +
  bearer auth); the HTTP API above is documented for self-hosted Riva NIM containers. A
  `RivaGRPCClient` implementing the same `STTProvider`/`TTSProvider` protocols is the
  documented swap-in for hosted access — nothing else in the pipeline changes.
- **Phase 6 — Ops (shipped):** `BackupManager` (full/incremental tar.gz; components: vault, configs,
  logical Redis dump, `pg_dump` — each gracefully skipped, never hard-failed, if unreachable),
  pluggable `BackupTarget` (local/NAS, S3-compatible via lazy `boto3`, SFTP via lazy `paramiko`),
  `RestoreManager` (dry-run, partial-component, integrity validation, automatic pre-restore safety
  snapshot), `UpdateManager` (Ed25519-signed packages, 8-step apply workflow with automatic rollback
  to the safety snapshot on any failure from migrations onward), `MaintenanceAgent` (keyword-routed
  deterministic tools: backup_now, verify_last_backup, restore_dry_run, resource_report),
  `psutil`-based CPU/memory/disk/GPU monitoring with linear capacity projection, offline release-
  signing script (`scripts/sign_update.py`).
- **Phase 7 — Security & deploy:** RBAC, OAuth2/JWT, API keys, audit, secrets, TLS;
  Grafana/Loki dashboards; Kubernetes manifests (GPU nodes, HA, HPA); CI/CD.
