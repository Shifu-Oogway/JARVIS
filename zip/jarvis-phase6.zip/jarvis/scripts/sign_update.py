#!/usr/bin/env python3
"""Build and sign a JARVIS self-update package.

Run this OFFLINE on a release machine — never on the JARVIS server itself.
JARVIS only ever needs the *public* key (configured via JARVIS_UPDATE_PUBLIC_KEY).

Usage
─────
  # one-time: generate your release signing keypair
  python scripts/sign_update.py keygen
  # writes release_private.key (KEEP SECRET, do not commit) and release_public.key

  # build + sign a package from a directory of changed files
  python scripts/sign_update.py build --src ./update_staging --version 1.1.0 \
      --notes "Adds the foo agent" --key release_private.key \
      --out jarvis_update_v1.1.0.zip

The --src directory should mirror the repo layout for whatever changed, e.g.:
  update_staging/
    backend/app/agents/new_agent.py
    backend/app/api/routes/new_route.py
    migrations/0007_add_table.sql        (optional — triggers alembic upgrade)
"""
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from app.ops.manifest import Manifest          # noqa: E402
from app.ops.signing import generate_keypair, sign  # noqa: E402


def cmd_keygen(args: argparse.Namespace) -> None:
    priv, pub = generate_keypair()
    Path("release_private.key").write_text(priv)
    Path("release_public.key").write_text(pub)
    print("Generated release_private.key (keep secret!) and release_public.key")
    print(f"\nSet this on your JARVIS server:\n  JARVIS_UPDATE_PUBLIC_KEY={pub}")


def cmd_build(args: argparse.Namespace) -> None:
    src = Path(args.src)
    if not src.is_dir():
        raise SystemExit(f"--src not found: {src}")
    private_key = Path(args.key).read_text().strip()

    manifest = Manifest(kind="update", version=args.version, notes=args.notes or "")
    files = [p for p in src.rglob("*") if p.is_file()]
    for f in files:
        manifest.add_file(str(f.relative_to(src)), f)

    manifest.signature = sign(manifest.signable_bytes(), private_key)

    out = Path(args.out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, arcname=str(f.relative_to(src)))
        z.writestr("manifest.json", manifest.to_json())
        if args.notes:
            z.writestr("release_notes.md", f"# {args.version}\n\n{args.notes}\n")

    print(f"Built {out}  ({len(files)} file(s), signed with {args.key})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("keygen", help="Generate a release signing keypair")

    p_build = sub.add_parser("build", help="Build and sign an update package")
    p_build.add_argument("--src", required=True, help="Directory of changed files")
    p_build.add_argument("--version", required=True, help="Semantic version, e.g. 1.1.0")
    p_build.add_argument("--notes", default="", help="Release notes (plain text)")
    p_build.add_argument("--key", required=True, help="Path to release_private.key")
    p_build.add_argument("--out", required=True, help="Output .zip path")

    args = parser.parse_args()
    {"keygen": cmd_keygen, "build": cmd_build}[args.command](args)


if __name__ == "__main__":
    main()
