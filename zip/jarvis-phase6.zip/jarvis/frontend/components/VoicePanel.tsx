"use client";

/**
 * Push-to-talk voice control.
 *
 * Browser audio caveat: MediaRecorder only encodes to webm/ogg containers
 * (no native WAV), while Riva's /v1/audio/transcriptions documents WAV/OGG/
 * OPUS support. We request 'audio/ogg;codecs=opus' where supported (Firefox)
 * and fall back to 'audio/webm;codecs=opus' (Chrome/Edge) — both carry Opus,
 * which Riva NIM accepts. If your deployment's ASR model rejects a container,
 * transcode server-side (ffmpeg) before calling RivaSTT.transcribe().
 */
import { useRef, useState } from "react";
import { transcribeAudio, synthesizeSpeech, sendChat } from "@/lib/api";

function pickMimeType(): string {
  const candidates = ["audio/ogg;codecs=opus", "audio/webm;codecs=opus", "audio/webm"];
  for (const c of candidates) {
    if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(c)) return c;
  }
  return "";
}

type Phase = "idle" | "recording" | "transcribing" | "thinking" | "speaking" | "error";

export function VoicePanel() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [transcript, setTranscript] = useState("");
  const [answer, setAnswer] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioElRef = useRef<HTMLAudioElement | null>(null);

  async function startRecording() {
    setErrorMsg(""); setTranscript(""); setAnswer("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = pickMimeType();
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => stream.getTracks().forEach((t) => t.stop());
      recorder.start();
      recorderRef.current = recorder;
      setPhase("recording");
    } catch {
      setErrorMsg("Microphone access denied or unavailable.");
      setPhase("error");
    }
  }

  async function stopAndSend() {
    const recorder = recorderRef.current;
    if (!recorder) return;
    const stopped = new Promise<void>((resolve) => { recorder.onstop = () => resolve(); });
    recorder.stop();
    await stopped;

    const blob = new Blob(chunksRef.current, { type: recorder.mimeType });
    setPhase("transcribing");
    try {
      const text = await transcribeAudio(blob);
      setTranscript(text);
      if (!text) {
        setPhase("idle");
        setErrorMsg("No speech backend configured (offline fallback) or nothing heard.");
        return;
      }

      setPhase("thinking");
      const result = await sendChat(text);
      setAnswer(result.answer);

      setPhase("speaking");
      const audioBlob = await synthesizeSpeech(result.answer);
      if (audioBlob && audioElRef.current) {
        audioElRef.current.src = URL.createObjectURL(audioBlob);
        await audioElRef.current.play().catch(() => {});
      }
      setPhase("idle");
    } catch (e) {
      setErrorMsg(e instanceof Error ? e.message : "Voice pipeline error");
      setPhase("error");
    }
  }

  const label: Record<Phase, string> = {
    idle: "Hold to talk", recording: "Listening…", transcribing: "Transcribing…",
    thinking: "Thinking…", speaking: "Speaking…", error: "Try again",
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <button
          onMouseDown={startRecording}
          onMouseUp={stopAndSend}
          onTouchStart={startRecording}
          onTouchEnd={stopAndSend}
          disabled={phase === "transcribing" || phase === "thinking" || phase === "speaking"}
          className={`rounded-full border px-4 py-2 font-mono text-[11px] uppercase tracking-widest transition-colors ${
            phase === "recording"
              ? "border-bad text-bad animate-pulse"
              : "border-edge text-live hover:border-live"
          } disabled:opacity-40`}
        >
          🎙 {label[phase]}
        </button>
        {phase !== "idle" && phase !== "error" && (
          <span className="live-dot" />
        )}
      </div>

      {transcript && (
        <p className="rounded border border-edge bg-ink/60 p-2 text-xs text-text">
          <span className="text-surge">You:</span> {transcript}
        </p>
      )}
      {answer && (
        <p className="rounded border border-edge bg-ink/60 p-2 text-xs text-text">
          <span className="text-live">JARVIS:</span> {answer}
        </p>
      )}
      {errorMsg && <p className="text-[11px] text-bad">{errorMsg}</p>}

      {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
      <audio ref={audioElRef} className="hidden" />
    </div>
  );
}
