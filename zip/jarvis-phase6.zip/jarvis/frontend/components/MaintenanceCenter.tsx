"use client";

import { useEffect, useState } from "react";
import {
  getBackups, createBackup, getResources, getUpdateHistory,
  type BackupEntry, type ResourceSnapshot, type UpdateRecordView,
} from "@/lib/api";

function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

function fmtDt(iso: string): string {
  return new Date(iso).toLocaleString(undefined, {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

function Gauge({ label, percent }: { label: string; percent: number }) {
  const color = percent > 85 ? "bg-bad" : percent > 60 ? "bg-warn" : "bg-live";
  return (
    <div>
      <div className="flex justify-between text-[10px] text-muted">
        <span>{label}</span><span>{percent.toFixed(0)}%</span>
      </div>
      <div className="mt-0.5 h-1.5 w-full rounded bg-edge">
        <div className={`h-1.5 rounded ${color} transition-all`} style={{ width: `${Math.min(percent, 100)}%` }} />
      </div>
    </div>
  );
}

export function MaintenanceCenter() {
  const [backups, setBackups] = useState<BackupEntry[]>([]);
  const [resources, setResources] = useState<ResourceSnapshot | null>(null);
  const [updates, setUpdates] = useState<UpdateRecordView[]>([]);
  const [creating, setCreating] = useState(false);
  const [tab, setTab] = useState<"backups" | "updates">("backups");

  const refresh = () => {
    getBackups().then(setBackups).catch(() => {});
    getResources().then(setResources).catch(() => {});
    getUpdateHistory().then(setUpdates).catch(() => {});
  };

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 8000);
    return () => clearInterval(id);
  }, []);

  async function runBackup(kind: "full" | "incremental") {
    setCreating(true);
    try { await createBackup(kind); refresh(); } catch { } finally { setCreating(false); }
  }

  return (
    <div className="p-4 space-y-4">
      {/* resource gauges */}
      {resources && (
        <div className="grid grid-cols-3 gap-3">
          <Gauge label="CPU" percent={resources.cpu_percent} />
          <Gauge label="Memory" percent={resources.memory.percent} />
          <Gauge label="Disk" percent={resources.disk.percent} />
        </div>
      )}
      {resources && resources.gpu.length > 0 && (
        <div className="space-y-1">
          {resources.gpu.map((g) => (
            <Gauge key={g.index} label={`GPU ${g.index} (${g.name})`} percent={g.utilization_percent} />
          ))}
        </div>
      )}

      {/* tabs */}
      <div className="flex gap-1 border-b border-edge/40">
        {(["backups", "updates"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-2 py-1 font-mono text-[10px] uppercase tracking-widest ${
              tab === t ? "text-surge border-b border-surge" : "text-muted"
            }`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "backups" && (
        <div className="space-y-2">
          <div className="flex gap-2">
            <button onClick={() => runBackup("full")} disabled={creating}
              className="rounded-md border border-edge px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-live hover:border-live disabled:opacity-40">
              {creating ? "Running…" : "Full backup"}
            </button>
            <button onClick={() => runBackup("incremental")} disabled={creating}
              className="rounded-md border border-edge px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-surge hover:border-surge disabled:opacity-40">
              Incremental
            </button>
          </div>
          <div className="max-h-40 space-y-1.5 overflow-auto">
            {backups.length === 0 && <p className="text-xs text-muted">No backups yet.</p>}
            {[...backups].reverse().map((b) => (
              <div key={b.id} className="rounded border border-edge p-2 text-[10px]">
                <div className="flex justify-between font-mono">
                  <span className="text-text">{b.kind}</span>
                  <span className="text-muted">{fmtDt(b.created_at)}</span>
                </div>
                <div className="mt-1 flex gap-2 text-muted">
                  <span>{fmtBytes(b.size_bytes)}</span>
                  {Object.entries(b.components).map(([name, c]) => (
                    <span key={name} className={c.status === "ok" ? "text-live" : "text-muted"}>
                      {name}:{c.status}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "updates" && (
        <div className="max-h-48 space-y-1.5 overflow-auto">
          {updates.length === 0 && (
            <p className="text-xs text-muted">
              No updates applied yet. Build a signed package with{" "}
              <code className="text-surge">scripts/sign_update.py</code> and upload via{" "}
              <code className="text-surge">POST /ops/update/upload</code>.
            </p>
          )}
          {[...updates].reverse().map((u) => (
            <div key={u.id} className="rounded border border-edge p-2 text-[10px]">
              <div className="flex justify-between font-mono">
                <span className="text-text">v{u.version}</span>
                <span className={
                  u.status === "succeeded" ? "text-live"
                    : u.status === "rolled_back" ? "text-warn" : "text-bad"
                }>{u.status}</span>
              </div>
              <div className="mt-1 text-muted">{fmtDt(u.applied_at)}</div>
              {u.error && <div className="mt-1 text-bad">{u.error}</div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
