"""Phase 5: wake-word, audio helpers, providers (mocked HTTP), VoiceSession — all offline."""
from __future__ import annotations

import base64
import json
import struct

import httpx
import pytest

from app.voice.audio import is_silence, pcm16_mean_amplitude, split_sentences, trailing_silence_ms
from app.voice.providers import NullSTT, NullTTS, RivaSTT, RivaTTS, VoiceError
from app.voice.session import VoiceSession, VoiceState
from app.voice.wake_word import AlwaysWake, TranscriptPrefixWakeWord, build_detector


# ── audio helpers ─────────────────────────────────────────────────────────────

def _pcm(amplitude: int, n: int = 160) -> bytes:
    """n samples of constant amplitude — 160 samples @16kHz = 10ms."""
    return struct.pack(f"<{n}h", *([amplitude] * n))


def test_mean_amplitude_silence_vs_loud():
    quiet = _pcm(10)
    loud = _pcm(5000)
    assert pcm16_mean_amplitude(quiet) < pcm16_mean_amplitude(loud)


def test_is_silence_threshold():
    assert is_silence(_pcm(10), threshold=500) is True
    assert is_silence(_pcm(5000), threshold=500) is False


def test_trailing_silence_detects_tail():
    chunks = [_pcm(5000), _pcm(5000), _pcm(10), _pcm(10), _pcm(10)]
    ms = trailing_silence_ms(chunks, threshold=500, sample_rate=16000)
    # 3 trailing silent chunks * 160 samples / 16000 Hz * 1000 = 30ms
    assert ms == pytest.approx(30.0, abs=0.01)


def test_trailing_silence_zero_when_loud_at_end():
    chunks = [_pcm(10), _pcm(10), _pcm(5000)]
    assert trailing_silence_ms(chunks, threshold=500) == 0.0


def test_split_sentences_basic():
    text = "Hello there. How are you? I am fine!"
    parts = split_sentences(text)
    assert parts == ["Hello there.", "How are you?", "I am fine!"]


def test_split_sentences_long_unpunctuated_wraps():
    text = "word " * 100   # no punctuation, must wrap by max_chars
    parts = split_sentences(text, max_chars=50)
    assert len(parts) > 1
    assert all(len(p) <= 55 for p in parts)   # allow small slack for boundary word


def test_split_sentences_empty():
    assert split_sentences("") == []
    assert split_sentences("   ") == []


# ── wake word ─────────────────────────────────────────────────────────────────

def test_wake_word_exact_match():
    d = TranscriptPrefixWakeWord("jarvis")
    woke, rest = d.detect("Jarvis what's the weather today")
    assert woke is True
    assert rest == "what's the weather today"


def test_wake_word_fuzzy_mishear():
    d = TranscriptPrefixWakeWord("jarvis")
    woke, _ = d.detect("Jarbis turn on the lights")   # plausible ASR mishear
    assert woke is True


def test_wake_word_rejects_unrelated():
    d = TranscriptPrefixWakeWord("jarvis")
    woke, _ = d.detect("the weather today is nice")
    assert woke is False


def test_wake_word_empty_transcript():
    d = TranscriptPrefixWakeWord("jarvis")
    woke, rest = d.detect("")
    assert woke is False and rest == ""


def test_always_wake_push_to_talk():
    d = AlwaysWake()
    woke, rest = d.detect("turn on the lights")
    assert woke is True
    assert rest == "turn on the lights"


def test_build_detector_modes():
    assert isinstance(build_detector("jarvis", "push_to_talk"), AlwaysWake)
    assert isinstance(build_detector("jarvis", "wake_word"), TranscriptPrefixWakeWord)


# ── providers: offline fallback ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_null_providers_are_safe_noops():
    stt, tts = NullSTT(), NullTTS()
    assert await stt.transcribe(b"\x00\x00") == ""
    assert await stt.healthy() is False
    assert await tts.synthesize("hello") == b""
    assert await tts.list_voices() == {}
    assert await tts.healthy() is False


# ── providers: Riva HTTP (mocked transport, real request shapes) ────────────────

def _mock_transport(handler) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url="http://fake-riva:9000")


@pytest.mark.asyncio
async def test_riva_stt_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/audio/transcriptions"
        assert b'name="language"' in request.content
        return httpx.Response(200, json={"text": "hello jarvis"})

    stt = RivaSTT("http://fake-riva:9000")
    stt._http = _mock_transport(handler)
    text = await stt.transcribe(b"\x00\x01" * 100, language="en-US")
    assert text == "hello jarvis"


@pytest.mark.asyncio
async def test_riva_stt_http_error_raises_voice_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="internal error")

    stt = RivaSTT("http://fake-riva:9000")
    stt._http = _mock_transport(handler)
    with pytest.raises(VoiceError):
        await stt.transcribe(b"\x00\x01")


@pytest.mark.asyncio
async def test_riva_tts_returns_audio_bytes():
    fake_wav = b"RIFF....WAVEfmt "

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/audio/synthesize"
        return httpx.Response(200, content=fake_wav)

    tts = RivaTTS("http://fake-riva:9000")
    tts._http = _mock_transport(handler)
    audio = await tts.synthesize("Hello world", voice="Magpie-Multilingual.EN-US.Aria")
    assert audio == fake_wav


@pytest.mark.asyncio
async def test_riva_tts_list_voices():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"en-US": {"voices": ["English-US.Female-1"]}})

    tts = RivaTTS("http://fake-riva:9000")
    tts._http = _mock_transport(handler)
    voices = await tts.list_voices()
    assert "en-US" in voices


@pytest.mark.asyncio
async def test_riva_health_check():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/health/ready"
        return httpx.Response(200)

    stt = RivaSTT("http://fake-riva:9000")
    stt._http = _mock_transport(handler)
    assert await stt.healthy() is True


# ── VoiceSession: the full turn ──────────────────────────────────────────────

class _MockSTT:
    def __init__(self, text="jarvis what is the weather"):
        self._text = text
    async def transcribe(self, audio, **kw):
        return self._text
    async def healthy(self): return True


class _MockTTS:
    async def synthesize(self, text, **kw):
        return f"wav:{text}".encode()
    async def list_voices(self): return {}
    async def healthy(self): return True


class _MockCore:
    def __init__(self, answer="It is sunny today."):
        self._answer = answer
        self.calls = []
    async def handle(self, request):
        self.calls.append(request)
        return {"answer": self._answer, "tasks": []}


def _session(stt=None, tts=None, core=None, **kw) -> VoiceSession:
    return VoiceSession(
        session_id="test-session",
        stt=stt or _MockSTT(), tts=tts or _MockTTS(),
        core=core or _MockCore(),
        wake_word=build_detector("jarvis", "wake_word"),
        **kw,
    )


@pytest.mark.asyncio
async def test_session_full_turn_wakes_and_responds():
    sent = []
    async def send(payload): sent.append(payload)

    core = _MockCore("It is sunny today.")
    session = _session(core=core)
    await session.handle_utterance(b"\x00\x01" * 50, send)

    types = [m["type"] for m in sent]
    assert "transcript" in types
    assert "response_text" in types
    assert "audio_chunk" in types
    assert "audio_end" in types
    assert core.calls == ["what is the weather"]   # wake word stripped
    assert session.state == VoiceState.LISTENING   # returns to listening after


@pytest.mark.asyncio
async def test_session_wake_miss_does_not_call_core():
    sent = []
    async def send(payload): sent.append(payload)

    core = _MockCore()
    stt = _MockSTT(text="the weather is nice today")   # no wake word
    session = _session(stt=stt, core=core)
    await session.handle_utterance(b"\x00\x01" * 50, send)

    types = [m["type"] for m in sent]
    assert "wake_miss" in types
    assert "response_text" not in types
    assert core.calls == []


@pytest.mark.asyncio
async def test_session_empty_transcript_is_noop():
    sent = []
    async def send(payload): sent.append(payload)
    stt = _MockSTT(text="")
    session = _session(stt=stt)
    await session.handle_utterance(b"\x00\x01" * 10, send)
    types = [m["type"] for m in sent]
    assert types == ["transcript"]


@pytest.mark.asyncio
async def test_session_push_audio_and_flush():
    session = _session(continuous=False)
    chunk = base64.b64encode(b"\x10\x00" * 80).decode()
    closed = session.push_audio(chunk)
    assert closed is False          # push-to-talk never auto-closes
    audio = session.flush()
    assert len(audio) == 160
    assert session._buffer == []    # cleared after flush


@pytest.mark.asyncio
async def test_session_continuous_mode_auto_closes_on_silence():
    session = _session(continuous=True, silence_ms=20, silence_threshold=500)
    loud = base64.b64encode(_pcm(5000)).decode()
    quiet = base64.b64encode(_pcm(10)).decode()
    assert session.push_audio(loud) is False
    assert session.push_audio(quiet) is False   # not enough trailing silence yet
    closed = session.push_audio(quiet)
    assert closed is True   # 2 quiet chunks @10ms = 20ms trailing silence


@pytest.mark.asyncio
async def test_session_interrupt_cancels_active_task():
    sent = []
    async def send(payload):
        sent.append(payload)

    class _SlowCore:
        async def handle(self, request):
            import asyncio
            await asyncio.sleep(5)   # never actually finishes in this test
            return {"answer": "too slow"}

    session = _session(core=_SlowCore())
    import asyncio
    task = asyncio.create_task(session.handle_utterance(b"\x00\x01" * 20, send))
    await asyncio.sleep(0.05)   # let it reach "thinking"
    interrupted = session.interrupt()
    assert interrupted is True
    await asyncio.sleep(0.05)
    assert any(m["type"] == "interrupted" for m in sent)


@pytest.mark.asyncio
async def test_session_interrupt_noop_when_idle():
    session = _session()
    assert session.interrupt() is False


@pytest.mark.asyncio
async def test_session_tts_error_propagates_gracefully():
    sent = []
    async def send(payload): sent.append(payload)

    class _FailingTTS:
        async def synthesize(self, text, **kw):
            raise VoiceError("TTS backend down")
        async def list_voices(self): return {}
        async def healthy(self): return False

    session = _session(tts=_FailingTTS())
    await session.handle_utterance(b"\x00\x01" * 30, send)
    types = [m["type"] for m in sent]
    assert "error" in types
