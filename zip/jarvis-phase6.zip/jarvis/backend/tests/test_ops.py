"""Phase 6: manifest, signing, backup/restore round-trip, update workflow,
resource monitoring — all offline, real filesystem operations in temp dirs."""
from __future__ import annotations

import asyncio
import json
import tarfile
import tempfile
import zipfile
from pathlib import Path

import pytest

from app.ops.manifest import Manifest, sha256_bytes, sha256_file
from app.ops.signing import generate_keypair, sign, verify
from app.ops.targets import LocalTarget, S3Target, TargetError
from app.ops.backup import BackupManager
from app.ops.restore import RestoreError, RestoreManager
from app.ops.update_manager import UpdateError, UpdateManager
from app.ops import resources as resource_mod


# ── manifest ──────────────────────────────────────────────────────────────────

def test_sha256_helpers_consistent(tmp_path):
    f = tmp_path / "x.txt"
    f.write_text("hello world")
    assert sha256_file(f) == sha256_bytes(b"hello world")


def test_manifest_roundtrip(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("content")
    m = Manifest(kind="backup", version="20260616")
    m.add_file("a.txt", f)
    restored = Manifest.from_json(m.to_json())
    assert restored.version == "20260616"
    assert restored.files[0].path == "a.txt"
    assert restored.files[0].sha256 == m.files[0].sha256


def test_manifest_digest_deterministic(tmp_path):
    f1 = tmp_path / "a.txt"; f1.write_text("A")
    f2 = tmp_path / "b.txt"; f2.write_text("B")
    m1 = Manifest()
    m1.add_file("a.txt", f1); m1.add_file("b.txt", f2)
    m2 = Manifest()
    m2.add_file("b.txt", f2); m2.add_file("a.txt", f1)   # different insertion order
    assert m1.overall_digest() == m2.overall_digest()    # sorted internally


def test_manifest_verify_integrity_detects_tamper(tmp_path):
    root = tmp_path / "root"; root.mkdir()
    f = root / "a.txt"; f.write_text("original")
    m = Manifest(); m.add_file("a.txt", f)
    assert m.verify_integrity(root) == []
    f.write_text("tampered!")
    problems = m.verify_integrity(root)
    assert len(problems) == 1 and "checksum mismatch" in problems[0]


def test_manifest_verify_integrity_detects_missing(tmp_path):
    root = tmp_path / "root"; root.mkdir()
    f = root / "a.txt"; f.write_text("original")
    m = Manifest(); m.add_file("a.txt", f)
    f.unlink()
    problems = m.verify_integrity(root)
    assert "missing: a.txt" in problems


# ── signing ───────────────────────────────────────────────────────────────────

def test_sign_and_verify_roundtrip():
    priv, pub = generate_keypair()
    data = b"manifest bytes to sign"
    sig = sign(data, priv)
    assert verify(data, sig, pub) is True


def test_verify_rejects_tampered_data():
    priv, pub = generate_keypair()
    sig = sign(b"original", priv)
    assert verify(b"tampered", sig, pub) is False


def test_verify_rejects_wrong_key():
    priv, pub1 = generate_keypair()
    _, pub2 = generate_keypair()
    sig = sign(b"data", priv)
    assert verify(b"data", sig, pub2) is False


def test_verify_garbage_signature_fails_closed():
    _, pub = generate_keypair()
    assert verify(b"data", "not-valid-base64!!", pub) is False


# ── targets ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_local_target_upload_download_roundtrip(tmp_path):
    src_dir = tmp_path / "src"; src_dir.mkdir()
    backup_root = tmp_path / "backups"
    target = LocalTarget(backup_root)

    f = src_dir / "test.tar.gz"; f.write_bytes(b"fake archive content")
    location = await target.upload(f, "test.tar.gz")
    assert Path(location).exists()

    dest = tmp_path / "downloaded.tar.gz"
    await target.download("test.tar.gz", dest)
    assert dest.read_bytes() == b"fake archive content"


@pytest.mark.asyncio
async def test_local_target_list_files(tmp_path):
    target = LocalTarget(tmp_path / "backups")
    (tmp_path / "backups").mkdir(parents=True, exist_ok=True)
    (tmp_path / "backups" / "one.tar.gz").write_bytes(b"x")
    (tmp_path / "backups" / "two.tar.gz").write_bytes(b"y")
    files = await target.list_files()
    assert files == ["one.tar.gz", "two.tar.gz"]


@pytest.mark.asyncio
async def test_local_target_download_missing_raises(tmp_path):
    target = LocalTarget(tmp_path / "backups")
    with pytest.raises(TargetError):
        await target.download("nope.tar.gz", tmp_path / "out.tar.gz")


def test_s3_target_requires_boto3_or_raises():
    # In this environment boto3 IS installed via prior phase deps possibly not.
    # Either it constructs fine (boto3 present) or raises a clear TargetError.
    try:
        import boto3  # noqa: F401
        S3Target(bucket="test-bucket")   # should not raise if boto3 present
    except ImportError:
        with pytest.raises(TargetError):
            S3Target(bucket="test-bucket")


# ── backup manager (real filesystem, no DB/Redis required) ────────────────────

@pytest.fixture
def backup_env(tmp_path, monkeypatch):
    """Isolated vault + backup dir, pointed at via env vars consumed by get_settings()."""
    vault_dir = tmp_path / "vault"
    vault_dir.mkdir()
    (vault_dir / "Research").mkdir()
    (vault_dir / "Research" / "note.md").write_text("---\ntype: research\n---\n\nHello vault.")

    backup_dir = tmp_path / "backups"

    monkeypatch.setenv("JARVIS_OBSIDIAN_VAULT_PATH", str(vault_dir))
    monkeypatch.setenv("JARVIS_BACKUP_DIR", str(backup_dir))
    from app.core.config import get_settings
    get_settings.cache_clear()

    yield {"vault_dir": vault_dir, "backup_dir": backup_dir}
    get_settings.cache_clear()


@pytest.mark.asyncio
async def test_backup_full_creates_catalog_entry(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    mgr = BackupManager(target)
    manifest = await mgr.create_backup(kind="full")

    assert manifest.components["vault"]["status"] == "ok"
    assert manifest.components["vault"]["files"] == 1
    # redis/postgres gracefully skipped — no live infra in this test
    assert manifest.components["redis"]["status"] in ("ok", "skipped")
    assert manifest.components["postgres"]["status"] == "skipped"

    catalog = mgr.list_backups()
    assert len(catalog) == 1
    assert catalog[0]["kind"] == "full"
    assert Path(catalog[0]["location"]).exists()


@pytest.mark.asyncio
async def test_backup_incremental_only_captures_changes(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    mgr = BackupManager(target)
    await mgr.create_backup(kind="full")

    # no new files yet — incremental should see zero vault files
    manifest2 = await mgr.create_backup(kind="incremental")
    assert manifest2.components["vault"].get("files", 0) == 0

    # add a new note, then incremental should pick it up
    import time; time.sleep(0.05)
    (backup_env["vault_dir"] / "Research" / "new.md").write_text("fresh content")
    manifest3 = await mgr.create_backup(kind="incremental")
    assert manifest3.components["vault"]["files"] == 1


@pytest.mark.asyncio
async def test_backup_catalog_persists_across_instances(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    mgr1 = BackupManager(target)
    await mgr1.create_backup(kind="full")

    mgr2 = BackupManager(target)   # fresh instance — should hydrate from catalog.json
    assert len(mgr2.list_backups()) == 1


# ── restore manager ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_restore_dry_run_does_not_modify(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    backups = BackupManager(target)
    manifest = await backups.create_backup(kind="full")
    restore = RestoreManager(target, backups)

    result = await restore.restore(manifest.id, dry_run=True)
    assert result["dry_run"] is True
    assert "vault" in result["components_would_restore"]


@pytest.mark.asyncio
async def test_restore_validate_reports_valid(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    backups = BackupManager(target)
    manifest = await backups.create_backup(kind="full")
    restore = RestoreManager(target, backups)

    check = await restore.validate(manifest.id)
    assert check["valid"] is True
    assert check["problems"] == []


@pytest.mark.asyncio
async def test_restore_unknown_backup_raises(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    backups = BackupManager(target)
    restore = RestoreManager(target, backups)
    with pytest.raises(RestoreError):
        await restore.validate("does-not-exist")


@pytest.mark.asyncio
async def test_restore_full_roundtrip_recovers_vault(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    backups = BackupManager(target)
    manifest = await backups.create_backup(kind="full")
    restore = RestoreManager(target, backups)

    # simulate data loss
    import shutil
    shutil.rmtree(backup_env["vault_dir"])

    result = await restore.restore(manifest.id, components=["vault"])
    assert result["dry_run"] is False
    assert result["results"]["vault"]["status"] == "ok"
    assert (backup_env["vault_dir"] / "Research" / "note.md").exists()


@pytest.mark.asyncio
async def test_restore_rejects_unknown_component(backup_env):
    target = LocalTarget(backup_env["backup_dir"])
    backups = BackupManager(target)
    manifest = await backups.create_backup(kind="full")
    restore = RestoreManager(target, backups)
    with pytest.raises(RestoreError):
        await restore.restore(manifest.id, components=["not_a_real_component"])


# ── update manager ────────────────────────────────────────────────────────────

def _build_signed_package(tmp_path: Path, version: str, priv_key: str,
                          files: dict[str, str]) -> Path:
    """Mirrors scripts/sign_update.py — build a signed .zip in-process for tests."""
    src = tmp_path / "pkg_src"
    src.mkdir()
    for rel, content in files.items():
        p = src / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)

    manifest = Manifest(kind="update", version=version)
    for rel in files:
        manifest.add_file(rel, src / rel)
    manifest.signature = sign(manifest.signable_bytes(), priv_key)

    out = tmp_path / f"update_{version}.zip"
    with zipfile.ZipFile(out, "w") as z:
        for rel in files:
            z.write(src / rel, arcname=rel)
        z.writestr("manifest.json", manifest.to_json())
    return out


@pytest.fixture
def update_env(backup_env, monkeypatch, tmp_path):
    priv, pub = generate_keypair()
    monkeypatch.setenv("JARVIS_UPDATE_PUBLIC_KEY", pub)
    monkeypatch.setenv("JARVIS_UPDATE_REQUIRE_SIGNATURE", "true")
    monkeypatch.setenv("JARVIS_UPDATE_STAGING_DIR", str(tmp_path / "staging"))
    from app.core.config import get_settings
    get_settings.cache_clear()
    yield {"priv": priv, "pub": pub, **backup_env}
    get_settings.cache_clear()


@pytest.mark.asyncio
async def test_update_rejects_unsigned_package(update_env, tmp_path):
    target = LocalTarget(update_env["backup_dir"])
    backups = BackupManager(target)
    restore = RestoreManager(target, backups)
    mgr = UpdateManager(backups, restore)

    # build an unsigned package (no manifest.signature)
    src = tmp_path / "unsigned_src"; src.mkdir()
    (src / "f.txt").write_text("x")
    m = Manifest(kind="update", version="1.0.0")
    m.add_file("f.txt", src / "f.txt")
    pkg = tmp_path / "unsigned.zip"
    with zipfile.ZipFile(pkg, "w") as z:
        z.write(src / "f.txt", arcname="f.txt")
        z.writestr("manifest.json", m.to_json())   # no signature field set

    record = await mgr.apply_package(pkg)
    assert record.status == "failed"
    assert "signature" in (record.error or "").lower()


@pytest.mark.asyncio
async def test_update_rejects_tampered_signed_package(update_env, tmp_path):
    target = LocalTarget(update_env["backup_dir"])
    backups = BackupManager(target)
    restore = RestoreManager(target, backups)
    mgr = UpdateManager(backups, restore)

    pkg = _build_signed_package(tmp_path, "1.0.0", update_env["priv"], {"f.txt": "original"})

    # tamper with the file AFTER signing, leaving manifest checksum stale
    extract_dir = tmp_path / "tamper_extract"
    with zipfile.ZipFile(pkg) as z:
        z.extractall(extract_dir)
    (extract_dir / "f.txt").write_text("TAMPERED")
    tampered_pkg = tmp_path / "tampered.zip"
    with zipfile.ZipFile(tampered_pkg, "w") as z:
        for f in extract_dir.iterdir():
            z.write(f, arcname=f.name)

    record = await mgr.apply_package(tampered_pkg)
    assert record.status == "failed"
    assert "integrity" in (record.error or "").lower()


@pytest.mark.asyncio
async def test_update_succeeds_with_valid_signed_package(update_env, tmp_path, monkeypatch):
    target = LocalTarget(update_env["backup_dir"])
    backups = BackupManager(target)
    restore = RestoreManager(target, backups)
    mgr = UpdateManager(backups, restore)

    # deploy into an isolated repo root so we don't touch the real backend
    fake_repo = tmp_path / "fake_repo"
    (fake_repo / "backend" / "app").mkdir(parents=True)
    monkeypatch.setattr(mgr, "_repo_root", fake_repo)

    pkg = _build_signed_package(
        tmp_path, "1.2.0", update_env["priv"],
        {"docs/NOTES.md": "release notes content"},
    )
    record = await mgr.apply_package(pkg)

    assert record.status == "succeeded"
    assert (fake_repo / "docs" / "NOTES.md").exists()
    step_names = [s["name"] for s in record.steps]
    assert "verify_signature" in step_names
    assert "create_backup" in step_names
    assert "health_check" in step_names
    assert record.safety_backup_id is not None


@pytest.mark.asyncio
async def test_update_history_tracks_attempts(update_env, tmp_path):
    target = LocalTarget(update_env["backup_dir"])
    backups = BackupManager(target)
    restore = RestoreManager(target, backups)
    mgr = UpdateManager(backups, restore)

    pkg = _build_signed_package(tmp_path, "0.0.1", update_env["priv"], {"x.txt": "y"})
    await mgr.apply_package(pkg)
    assert len(mgr.history()) == 1
    assert mgr.history()[0]["version"] == "0.0.1"


def test_update_signature_disabled_allows_unsigned(update_env, tmp_path, monkeypatch):
    monkeypatch.setenv("JARVIS_UPDATE_REQUIRE_SIGNATURE", "false")
    from app.core.config import get_settings
    get_settings.cache_clear()
    settings = get_settings()
    assert settings.update_require_signature is False
    get_settings.cache_clear()


# ── resources ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_resource_snapshot_shape():
    snap = await resource_mod.snapshot()
    assert "cpu_percent" in snap
    assert "memory" in snap and "percent" in snap["memory"]
    assert "disk" in snap and "percent" in snap["disk"]
    assert "gpu" in snap and isinstance(snap["gpu"], list)


def test_capacity_projection_increasing_trend():
    history = [
        {"ts": "2026-06-01T00:00:00+00:00", "used_gb": 10.0},
        {"ts": "2026-06-08T00:00:00+00:00", "used_gb": 17.0},
        {"ts": "2026-06-15T00:00:00+00:00", "used_gb": 24.0},
    ]
    result = resource_mod.project_disk_exhaustion(history)
    assert result["trend"] == "increasing"
    assert result["gb_per_day"] == pytest.approx(1.0, abs=0.01)


def test_capacity_projection_insufficient_data():
    assert resource_mod.project_disk_exhaustion([{"ts": "2026-06-01T00:00:00+00:00", "used_gb": 1}]) is None


def test_capacity_projection_stable_trend():
    history = [
        {"ts": "2026-06-01T00:00:00+00:00", "used_gb": 10.0},
        {"ts": "2026-06-08T00:00:00+00:00", "used_gb": 10.0},
    ]
    result = resource_mod.project_disk_exhaustion(history)
    assert result["trend"] == "stable_or_decreasing"


# ── Maintenance Agent routing ─────────────────────────────────────────────────

def test_maintenance_agent_routes_backup_keyword():
    from app.agents.maintenance_agent import MaintenanceAgent
    from app.infrastructure.nim.router import NIMRouter
    agent = MaintenanceAgent(NIMRouter())
    assert agent._match_tool("please create a backup now") == "backup_now"
    assert agent._match_tool("run a backup") == "backup_now"


def test_maintenance_agent_routes_verify_keyword():
    from app.agents.maintenance_agent import MaintenanceAgent
    from app.infrastructure.nim.router import NIMRouter
    agent = MaintenanceAgent(NIMRouter())
    assert agent._match_tool("verify the last backup integrity") == "verify_last_backup"


def test_maintenance_agent_routes_resource_keyword():
    from app.agents.maintenance_agent import MaintenanceAgent
    from app.infrastructure.nim.router import NIMRouter
    agent = MaintenanceAgent(NIMRouter())
    assert agent._match_tool("give me a system health report") == "resource_report"


def test_maintenance_agent_no_match_for_unrelated():
    from app.agents.maintenance_agent import MaintenanceAgent
    from app.infrastructure.nim.router import NIMRouter
    agent = MaintenanceAgent(NIMRouter())
    assert agent._match_tool("what is the capital of France") is None


@pytest.mark.asyncio
async def test_maintenance_agent_executes_registered_tool():
    from app.agents.maintenance_agent import MaintenanceAgent
    from app.infrastructure.nim.router import NIMRouter
    agent = MaintenanceAgent(NIMRouter())

    async def fake_backup():
        return "Backup xyz created."
    agent.register_tool("backup_now", fake_backup)

    result = await agent._execute("create a backup now", messages=[])
    assert result == "Backup xyz created."
