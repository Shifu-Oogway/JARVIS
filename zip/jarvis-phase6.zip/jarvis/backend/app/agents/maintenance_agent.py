"""Maintenance Agent — backups, updates, rollback, resource monitoring.

Unlike the other agents (which are LLM-driven by default), most maintenance
operations need to be *deterministic*, not generated text — you don't want
an LLM improvising what "backup now" means. So this agent keyword-routes
objectives to registered tools first, falling back to the LLM only for
free-form questions ("summarise yesterday's backup status") where natural
language synthesis is actually the right tool.
"""
from __future__ import annotations

import re

from app.agents.base import BaseAgent
from app.domain.enums import AgentRole

_ROUTES: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bbackup\b.*\bnow\b|\bcreate\b.*\bbackup\b|\brun\b.*\bbackup\b", re.I), "backup_now"),
    (re.compile(r"\bverify\b.*\bbackup\b|\bcheck\b.*\bbackup\b.*\bintegrity\b", re.I), "verify_last_backup"),
    (re.compile(r"\brestore\b.*\bdry.?run\b|\btest\b.*\brestore\b", re.I), "restore_dry_run"),
    (re.compile(r"\bresource\b.*\breport\b|\bsystem\b.*\bhealth\b|\bcapacity\b", re.I), "resource_report"),
]


class MaintenanceAgent(BaseAgent):
    role = AgentRole.MAINTENANCE
    system_prompt = (
        "You are JARVIS's Maintenance Agent. You manage backups, self-updates, "
        "rollbacks, and resource monitoring. For deterministic operations you use "
        "your tools directly rather than improvising; for status summaries you "
        "write clear, concise operational reports."
    )

    def _match_tool(self, objective: str) -> str | None:
        for pattern, tool_name in _ROUTES:
            if pattern.search(objective):
                return tool_name
        return None

    async def _execute(self, objective: str, messages: list[dict]) -> str:
        tool_name = self._match_tool(objective)
        if tool_name and tool_name in self.tools:
            try:
                return await self.use_tool(tool_name)
            except Exception as exc:   # noqa: BLE001 — surface as a normal agent result, not a crash
                return f"Tool {tool_name!r} failed: {exc}"
        # No deterministic match — fall back to LLM synthesis (e.g. status summaries)
        return await super()._execute(objective, messages)
