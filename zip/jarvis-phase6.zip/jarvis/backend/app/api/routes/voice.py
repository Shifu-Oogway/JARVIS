"""Voice API.

REST (simple, file-based — good for the dashboard's push-to-talk button
and for any client that records a whole utterance before sending it)
────────────────────────────────────────────────────────────────────
POST /voice/stt      multipart audio file → {"text": "..."}
POST /voice/tts      {"text": "..."} → audio/wav bytes
GET  /voice/voices   → available voices by language
GET  /voice/health   → backend reachability

WebSocket (full session protocol — continuous listening, wake word,
barge-in, sentence-streamed TTS)
────────────────────────────────────────────────────────────────────
WS /ws/voice
  client → {"type": "config", "language": "en-US", "continuous": true, "wake_word": "jarvis"}
          {"type": "audio_chunk", "data": "<base64 pcm16>"}
          {"type": "audio_end"}                      (push-to-talk: close utterance)
          {"type": "interrupt"}                       (barge-in)
  server → {"type": "transcript", "text": "..."}
          {"type": "wake_miss", "text": "..."}        (heard something, not addressed to JARVIS)
          {"type": "thinking"}
          {"type": "response_text", "text": "..."}
          {"type": "audio_chunk", "seq": 0, "final": false, "data": "<base64 wav>"}
          {"type": "audio_end"}
          {"type": "interrupted"}
          {"type": "error", "message": "..."}
"""
from __future__ import annotations

from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import Response

from app.core.config import get_settings
from app.voice.providers import STTProvider, TTSProvider, VoiceError
from app.voice.session import VoiceSession
from app.voice.wake_word import build_detector

router = APIRouter(tags=["voice"])


def _stt(request: Request) -> STTProvider:
    return request.app.state.stt_provider


def _tts(request: Request) -> TTSProvider:
    return request.app.state.tts_provider


# ── REST ──────────────────────────────────────────────────────────────────────

@router.get("/voice/health")
async def voice_health(stt: STTProvider = Depends(_stt), tts: TTSProvider = Depends(_tts)) -> dict:
    return {"stt_healthy": await stt.healthy(), "tts_healthy": await tts.healthy()}


@router.get("/voice/voices")
async def voices(tts: TTSProvider = Depends(_tts)) -> dict:
    try:
        return await tts.list_voices()
    except VoiceError as exc:
        raise HTTPException(502, str(exc)) from exc


@router.post("/voice/stt")
async def speech_to_text(file: UploadFile, stt: STTProvider = Depends(_stt)) -> dict:
    audio = await file.read()
    if not audio:
        raise HTTPException(422, "Empty audio upload")
    try:
        text = await stt.transcribe(audio, language=get_settings().voice_default_language,
                                    mime=file.content_type or "audio/wav")
    except VoiceError as exc:
        raise HTTPException(502, str(exc)) from exc
    return {"text": text}


@router.post("/voice/tts")
async def text_to_speech(body: dict, tts: TTSProvider = Depends(_tts)) -> Response:
    text = body.get("text")
    if not text:
        raise HTTPException(422, "text is required")
    settings = get_settings()
    try:
        audio = await tts.synthesize(
            text,
            language=body.get("language", settings.voice_default_language),
            voice=body.get("voice", settings.voice_default_voice),
        )
    except VoiceError as exc:
        raise HTTPException(502, str(exc)) from exc
    if not audio:
        raise HTTPException(503, "TTS backend unavailable (offline fallback active)")
    return Response(content=audio, media_type="audio/wav")


# ── WebSocket session ─────────────────────────────────────────────────────────

@router.websocket("/ws/voice")
async def voice_ws(ws: WebSocket) -> None:
    await ws.accept()
    settings = get_settings()
    stt: STTProvider = ws.app.state.stt_provider
    tts: TTSProvider = ws.app.state.tts_provider
    core = ws.app.state.core

    session = VoiceSession(
        session_id=str(uuid4()),
        stt=stt, tts=tts, core=core,
        wake_word=build_detector(settings.voice_wake_word, mode="wake_word"),
        language=settings.voice_default_language,
        voice=settings.voice_default_voice,
        continuous=False,
        silence_ms=settings.voice_silence_ms,
        silence_threshold=settings.voice_silence_threshold,
    )

    async def send(payload: dict) -> None:
        await ws.send_json(payload)

    await send({"type": "session_started", "session_id": session.session_id})

    try:
        while True:
            msg = await ws.receive_json()
            mtype = msg.get("type")

            if mtype == "config":
                if "language" in msg:
                    session.language = msg["language"]
                if "voice" in msg:
                    session.voice = msg["voice"]
                if "continuous" in msg:
                    session.continuous = bool(msg["continuous"])
                if "wake_word" in msg:
                    mode = "push_to_talk" if not session.continuous else "wake_word"
                    session.wake_word = build_detector(msg["wake_word"], mode=mode)
                await send({"type": "config_ack"})

            elif mtype == "audio_chunk":
                closed = session.push_audio(msg["data"])
                if closed:
                    audio = session.flush()
                    await session.handle_utterance(audio, send)

            elif mtype == "audio_end":
                audio = session.flush()
                if audio:
                    await session.handle_utterance(audio, send)

            elif mtype == "interrupt":
                interrupted = session.interrupt()
                if not interrupted:
                    await send({"type": "interrupt_noop"})

            else:
                await send({"type": "error", "message": f"Unknown message type: {mtype!r}"})

    except WebSocketDisconnect:
        pass
