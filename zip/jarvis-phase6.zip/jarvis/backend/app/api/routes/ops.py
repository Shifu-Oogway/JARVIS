"""Ops API — backup, restore, self-update, resource monitoring.

POST /ops/backup                  {"kind": "full"|"incremental"} → trigger backup
GET  /ops/backups                 list backup catalog
GET  /ops/backups/{id}/validate   integrity check only, no restore
POST /ops/restore                 {"backup_id", "components": [...], "dry_run": bool}
POST /ops/update/upload           multipart .zip/.tar.gz → stages package, returns package_id
POST /ops/update/apply            {"package_id"} → runs the 8-step update workflow
GET  /ops/update/history          list past update attempts
GET  /ops/resources               live CPU/mem/disk/GPU snapshot
"""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile

from app.ops import resources as resource_mod
from app.ops.backup import BackupManager
from app.ops.restore import RestoreError, RestoreManager
from app.ops.update_manager import UpdateManager

router = APIRouter(prefix="/ops", tags=["ops"])


def _backups(request: Request) -> BackupManager:
    return request.app.state.backup_manager


def _restores(request: Request) -> RestoreManager:
    return request.app.state.restore_manager


def _updates(request: Request) -> UpdateManager:
    return request.app.state.update_manager


# ── backups ───────────────────────────────────────────────────────────────────

@router.post("/backup")
async def create_backup(body: dict, mgr: BackupManager = Depends(_backups)) -> dict:
    kind = body.get("kind", "full")
    try:
        manifest = await mgr.create_backup(kind=kind)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return manifest.to_dict()


@router.get("/backups")
async def list_backups(mgr: BackupManager = Depends(_backups)) -> list[dict]:
    return mgr.list_backups()


@router.get("/backups/{backup_id}/validate")
async def validate_backup(backup_id: str, restore: RestoreManager = Depends(_restores)) -> dict:
    try:
        return await restore.validate(backup_id)
    except RestoreError as exc:
        raise HTTPException(404, str(exc)) from exc


# ── restore ───────────────────────────────────────────────────────────────────

@router.post("/restore")
async def restore_backup(body: dict, restore: RestoreManager = Depends(_restores)) -> dict:
    backup_id = body.get("backup_id")
    if not backup_id:
        raise HTTPException(422, "backup_id is required")
    try:
        return await restore.restore(
            backup_id,
            components=body.get("components"),
            dry_run=body.get("dry_run", False),
        )
    except RestoreError as exc:
        raise HTTPException(422, str(exc)) from exc


# ── self-update ───────────────────────────────────────────────────────────────

@router.post("/update/upload")
async def upload_update(file: UploadFile, mgr: UpdateManager = Depends(_updates)) -> dict:
    if not file.filename or not (file.filename.endswith(".zip") or file.filename.endswith(".tar.gz")):
        raise HTTPException(422, "Expected a .zip or .tar.gz update package")
    import tempfile
    data = await file.read()
    with tempfile.NamedTemporaryFile(suffix=Path(file.filename).suffix, delete=False) as tmp:
        tmp.write(data)
        tmp_path = Path(tmp.name)
    staged = mgr.stage_package(tmp_path)
    tmp_path.unlink(missing_ok=True)
    return {"package_id": staged.name, "staged_path": str(staged), "size_bytes": len(data)}


@router.post("/update/apply")
async def apply_update(body: dict, mgr: UpdateManager = Depends(_updates)) -> dict:
    package_id = body.get("package_id")
    if not package_id:
        raise HTTPException(422, "package_id is required")
    from app.core.config import get_settings
    package_path = Path(get_settings().update_staging_dir) / package_id
    if not package_path.exists():
        raise HTTPException(404, f"Staged package not found: {package_id!r}")
    record = await mgr.apply_package(package_path)
    return record.to_dict()


@router.get("/update/history")
async def update_history(mgr: UpdateManager = Depends(_updates)) -> list[dict]:
    return mgr.history()


# ── resources ─────────────────────────────────────────────────────────────────

@router.get("/resources")
async def resources() -> dict:
    return await resource_mod.snapshot()
