"""JARVIS backend entrypoint."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.metrics import MetricsMiddleware, metrics_app

from app.agents.registry import AgentRegistry
from app.api.router import api_router
from app.core.config import get_settings
from app.core.events import event_bus
from app.core.logging import configure_logging, get_logger
from app.core_engine.jarvis_core import JarvisCore
from app.domain.enums import AgentRole
from app.workflows.executor import DAGExecutor
from app.scheduler.engine import SchedulerEngine
from app.scheduler.store import JobStore
from app.voice.providers import build_providers
from app.ops import resources as resource_mod
from app.ops.backup import BackupManager
from app.ops.restore import RestoreManager
from app.ops.update_manager import UpdateManager
from app.ops.targets import LocalTarget
from app.infrastructure.obsidian.graph import KnowledgeGraph
from app.infrastructure.obsidian.vault import ObsidianVault
from app.memory.compression import MemoryCompressor
from app.memory.context_engine import ContextAssemblyEngine
from app.memory.embeddings import get_embedding_provider
from app.memory.reranker import Reranker
from app.memory.store import MemoryStore
from app.infrastructure.db.session import init_models
from app.infrastructure.nim.router import NIMRouter

log = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.debug)
    log.info("jarvis_boot", environment=settings.environment)

    await event_bus.connect()
    nim_router = NIMRouter()
    await nim_router.start()
    agents = AgentRegistry(nim_router)

    # --- Memory & Obsidian subsystem (Phase 2) ---
    vault = ObsidianVault(settings.obsidian_vault_path)
    try:
        vault.ensure_structure()
    except OSError as exc:
        log.warning("vault_unavailable", error=str(exc))
    embedder = get_embedding_provider()
    store = MemoryStore(embedder)
    try:
        n = await store.hydrate_from_vault(vault)
        log.info("memory_hydrated", notes=n)
    except Exception as exc:  # noqa: BLE001
        log.warning("memory_hydrate_failed", error=str(exc))
    reranker = Reranker()
    graph = KnowledgeGraph.build(vault) if vault.root.exists() else KnowledgeGraph()
    context_engine = ContextAssemblyEngine(
        store, reranker, vault, graph, token_budget=settings.context_token_budget)
    compressor = MemoryCompressor(nim_router, vault, store)
    dag_executor = DAGExecutor(agents)
    core = JarvisCore(nim_router, agents, context_engine=context_engine,
                      compressor=compressor, dag_executor=dag_executor)

    app.state.nim_router = nim_router
    app.state.agents = agents
    app.state.core = core
    app.state.vault = vault
    app.state.memory_store = store
    app.state.context_engine = context_engine
    app.state.knowledge_graph = graph
    app.state.dag_executor = dag_executor

    # ── Scheduler (Phase 4) ──
    job_store = JobStore()
    scheduler = SchedulerEngine(job_store)
    app.state.scheduler = scheduler
    await scheduler.start(core, dag_executor)

    # ── Voice (Phase 5) ──
    stt_provider, tts_provider = build_providers()
    app.state.stt_provider = stt_provider
    app.state.tts_provider = tts_provider

    # ── Ops: backup / restore / self-update (Phase 6) ──
    backup_target = LocalTarget(settings.backup_dir)
    backup_manager = BackupManager(backup_target)
    restore_manager = RestoreManager(backup_target, backup_manager)
    update_manager = UpdateManager(backup_manager, restore_manager)
    app.state.backup_manager = backup_manager
    app.state.restore_manager = restore_manager
    app.state.update_manager = update_manager

    # wire deterministic tools into the Maintenance Agent
    maintenance_agent = agents.get(AgentRole.MAINTENANCE)

    async def _backup_now() -> str:
        manifest = await backup_manager.create_backup(kind="full")
        ok = [k for k, v in manifest.components.items() if v.get("status") == "ok"]
        skipped = [k for k, v in manifest.components.items() if v.get("status") == "skipped"]
        msg = f"Backup {manifest.id} created. Captured: {', '.join(ok) or 'none'}."
        if skipped:
            msg += f" Skipped: {', '.join(skipped)}."
        return msg

    async def _verify_last_backup() -> str:
        latest = backup_manager.latest_full() or (
            backup_manager.list_backups()[-1] if backup_manager.list_backups() else None
        )
        if not latest:
            return "No backups exist yet."
        result = await restore_manager.validate(latest["id"])
        return (f"Backup {latest['id']} integrity: "
               f"{'VALID' if result['valid'] else 'PROBLEMS FOUND: ' + '; '.join(result['problems'])}")

    async def _restore_dry_run() -> str:
        latest = backup_manager.latest_full() or (
            backup_manager.list_backups()[-1] if backup_manager.list_backups() else None
        )
        if not latest:
            return "No backups exist yet — nothing to test-restore."
        result = await restore_manager.restore(latest["id"], dry_run=True)
        return f"Dry-run restore of {latest['id']}: would restore {result['components_would_restore']}."

    async def _resource_report() -> str:
        snap = await resource_mod.snapshot()
        gpu_line = f", {len(snap['gpu'])} GPU(s)" if snap["gpu"] else ""
        return (f"CPU {snap['cpu_percent']}% · "
               f"Memory {snap['memory']['percent']}% ({snap['memory']['used_gb']}/{snap['memory']['total_gb']} GB) · "
               f"Disk {snap['disk']['percent']}% ({snap['disk']['used_gb']}/{snap['disk']['total_gb']} GB){gpu_line}")

    maintenance_agent.register_tool("backup_now", _backup_now)
    maintenance_agent.register_tool("verify_last_backup", _verify_last_backup)
    maintenance_agent.register_tool("restore_dry_run", _restore_dry_run)
    maintenance_agent.register_tool("resource_report", _resource_report)

    try:
        await init_models()
    except Exception as exc:  # noqa: BLE001 - boot without DB in pure-dev/offline runs
        log.warning("db_init_skipped", error=str(exc))

    yield

    await scheduler.stop()
    for provider in (stt_provider, tts_provider):
        if hasattr(provider, "aclose"):
            await provider.aclose()
    await nim_router.stop()
    await event_bus.close()
    log.info("jarvis_shutdown")


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="JARVIS", version="0.1.0", lifespan=lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(MetricsMiddleware)
    app.include_router(api_router)
    app.mount("/metrics", metrics_app)
    return app


app = create_app()
