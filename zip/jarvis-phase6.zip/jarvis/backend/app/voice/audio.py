"""Pure-stdlib audio helpers — no numpy dependency.

Endpointing: a lightweight energy-based silence detector over 16-bit PCM,
used to auto-close an utterance in continuous-listening mode.

Sentence chunking: splits a TTS reply into clauses so synthesis (and thus
playback) can start before the full reply is generated — the practical
approximation of "streaming TTS" when the backend's synth call returns a
whole clip per request (NIM's offline /v1/audio/synthesize).
"""
from __future__ import annotations

import re
import struct

# ── PCM16 silence detection ────────────────────────────────────────────────────

def pcm16_mean_amplitude(chunk: bytes) -> float:
    """Mean absolute amplitude of little-endian 16-bit PCM samples."""
    if len(chunk) < 2:
        return 0.0
    n = len(chunk) // 2
    samples = struct.unpack(f"<{n}h", chunk[: n * 2])
    return sum(abs(s) for s in samples) / n


def is_silence(chunk: bytes, threshold: int) -> bool:
    return pcm16_mean_amplitude(chunk) < threshold


def trailing_silence_ms(chunks: list[bytes], threshold: int,
                        sample_rate: int = 16000, bytes_per_sample: int = 2) -> float:
    """How many trailing milliseconds (from the most recent chunks) are silent."""
    ms = 0.0
    for chunk in reversed(chunks):
        if not is_silence(chunk, threshold):
            break
        samples = len(chunk) / bytes_per_sample
        ms += (samples / sample_rate) * 1000
    return ms


# ── sentence chunking for pseudo-streaming TTS ─────────────────────────────────

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text: str, max_chars: int = 220) -> list[str]:
    """Split into speakable chunks: sentence boundaries, capped length as a
    fallback for unpunctuated text so no single synth call is too large."""
    text = text.strip()
    if not text:
        return []
    sentences = [s.strip() for s in _SENTENCE_SPLIT.split(text) if s.strip()]
    chunks: list[str] = []
    for s in sentences:
        while len(s) > max_chars:
            cut = s.rfind(" ", 0, max_chars)
            cut = cut if cut > 0 else max_chars
            chunks.append(s[:cut].strip())
            s = s[cut:].strip()
        if s:
            chunks.append(s)
    return chunks
