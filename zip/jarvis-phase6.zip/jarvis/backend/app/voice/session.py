"""VoiceSession — one continuous voice conversation.

State machine
─────────────
listening → (utterance closed) → transcribing → [wake check] → thinking → speaking → listening
                                                        │
                                                 (no wake word) → listening  (discarded)

Barge-in: the client sends {"type": "interrupt"} the instant the user starts
talking over JARVIS. The session cancels the in-flight synthesis/dispatch task
and immediately returns to listening — actual audio *playback* cancellation is
the client's job (stop the <audio>/AudioContext source), since the backend has
already handed chunks over the wire by the time it can react.
"""
from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass, field
from enum import StrEnum

from app.core.events import event_bus
from app.core.logging import get_logger
from app.voice.audio import is_silence, split_sentences, trailing_silence_ms
from app.voice.providers import STTProvider, TTSProvider, VoiceError
from app.voice.wake_word import WakeWordDetector

log = get_logger("voice.session")


class VoiceState(StrEnum):
    LISTENING    = "listening"
    TRANSCRIBING = "transcribing"
    THINKING     = "thinking"
    SPEAKING     = "speaking"


@dataclass
class VoiceSession:
    session_id: str
    stt: STTProvider
    tts: TTSProvider
    wake_word: WakeWordDetector
    core: object                      # JarvisCore — typed loosely to dodge circular import
    language: str = "en-US"
    voice: str = ""
    continuous: bool = False          # False = push-to-talk (explicit audio_end), True = auto VAD endpointing
    silence_ms: int = 700
    silence_threshold: int = 500

    state: VoiceState = VoiceState.LISTENING
    _buffer: list[bytes] = field(default_factory=list)
    _active_task: asyncio.Task | None = None

    # ── ingestion ────────────────────────────────────────────────────────────
    def push_audio(self, chunk_b64: str) -> bool:
        """Append a base64-encoded PCM16 chunk. Returns True if this closes
        the utterance (continuous mode trailing-silence detection)."""
        chunk = base64.b64decode(chunk_b64)
        self._buffer.append(chunk)
        if self.continuous and len(self._buffer) >= 3:
            trailing = trailing_silence_ms(self._buffer, self.silence_threshold)
            if trailing >= self.silence_ms and not is_silence(b"".join(self._buffer), self.silence_threshold):
                return True
        return False

    def flush(self) -> bytes:
        audio = b"".join(self._buffer)
        self._buffer.clear()
        return audio

    # ── interrupt / barge-in ─────────────────────────────────────────────────
    def interrupt(self) -> bool:
        if self._active_task and not self._active_task.done():
            self._active_task.cancel()
            self.state = VoiceState.LISTENING
            return True
        return False

    # ── the core turn: STT → wake check → Jarvis Core → TTS ────────────────────
    async def handle_utterance(self, wav_bytes: bytes, send) -> None:
        """`send` is an async callable(dict) — typically ws.send_json."""
        self._active_task = asyncio.current_task()
        try:
            self.state = VoiceState.TRANSCRIBING
            transcript = await self.stt.transcribe(wav_bytes, language=self.language)
            await send({"type": "transcript", "text": transcript})
            await event_bus.publish("voice.transcript", {"session": self.session_id, "text": transcript})

            if not transcript:
                self.state = VoiceState.LISTENING
                return

            woke, directive = self.wake_word.detect(transcript)
            if not woke or not directive:
                await send({"type": "wake_miss", "text": transcript})
                self.state = VoiceState.LISTENING
                return

            self.state = VoiceState.THINKING
            await send({"type": "thinking"})
            result = await self.core.handle(directive)
            answer = result.get("answer", "")
            await send({"type": "response_text", "text": answer})
            await event_bus.publish("voice.response", {"session": self.session_id, "text": answer})

            self.state = VoiceState.SPEAKING
            await self._speak(answer, send)

        except asyncio.CancelledError:
            await send({"type": "interrupted"})
            raise
        except VoiceError as exc:
            await send({"type": "error", "message": str(exc)})
        finally:
            self.state = VoiceState.LISTENING
            self._active_task = None

    async def _speak(self, text: str, send) -> None:
        """Sentence-chunked pseudo-streaming: synthesize and send clip-by-clip
        so playback can begin before the whole reply is voiced."""
        chunks = split_sentences(text) or [text]
        for i, sentence in enumerate(chunks):
            try:
                audio = await self.tts.synthesize(sentence, language=self.language, voice=self.voice)
            except VoiceError as exc:
                await send({"type": "error", "message": str(exc)})
                return
            if audio:
                await send({
                    "type": "audio_chunk", "seq": i, "final": i == len(chunks) - 1,
                    "data": base64.b64encode(audio).decode("ascii"),
                })
        await send({"type": "audio_end"})
