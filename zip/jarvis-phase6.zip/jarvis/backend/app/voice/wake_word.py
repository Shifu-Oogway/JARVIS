"""Wake-word detection.

Phase 5 ships a transcript-based detector: since the pipeline already runs STT
on every utterance, checking whether the recognised text starts with the wake
word is zero-cost and works with any ASR backend. Fuzzy matching absorbs minor
ASR mishears ("jarvis" → "jarbis", "travis").

A dedicated low-latency *pre-transcription* engine (Porcupine, openWakeWord)
is a documented swap-in: implement WakeWordDetector and register it — nothing
else in the voice pipeline needs to change.
"""
from __future__ import annotations

import re
from difflib import SequenceMatcher
from typing import Protocol


class WakeWordDetector(Protocol):
    def detect(self, transcript: str) -> tuple[bool, str]:
        """Return (woke, remainder) — remainder is the transcript with the
        wake word stripped, ready to forward to Jarvis Core."""
        ...


class TranscriptPrefixWakeWord:
    def __init__(self, wake_word: str = "jarvis", similarity_threshold: float = 0.72) -> None:
        self.wake_word = wake_word.lower().strip()
        self.threshold = similarity_threshold

    def detect(self, transcript: str) -> tuple[bool, str]:
        text = transcript.strip()
        if not text:
            return False, ""
        words = re.findall(r"[a-z0-9']+", text.lower())
        if not words:
            return False, ""
        first = words[0]
        score = SequenceMatcher(None, first, self.wake_word).ratio()
        if score >= self.threshold:
            # strip the first word (preserving original casing/punctuation for the rest)
            rest = re.sub(r"^\s*\S+[,:\-]?\s*", "", text, count=1)
            return True, rest.strip()
        return False, text


class AlwaysWake:
    """Push-to-talk mode: every utterance is directed at JARVIS, no wake word needed."""
    def detect(self, transcript: str) -> tuple[bool, str]:
        return True, transcript.strip()


def build_detector(wake_word: str, mode: str = "wake_word") -> WakeWordDetector:
    if mode == "push_to_talk":
        return AlwaysWake()
    return TranscriptPrefixWakeWord(wake_word)
