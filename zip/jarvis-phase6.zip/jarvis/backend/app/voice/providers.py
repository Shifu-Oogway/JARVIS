"""STT / TTS provider abstraction.

Real implementation: NVIDIA Riva Speech NIM's self-hosted HTTP API
(confirmed shape — see docs.nvidia.com/nim/speech):

  POST {base}/v1/audio/transcriptions   multipart: file=<wav>, language=<code>
  POST {base}/v1/audio/synthesize       multipart: text, language, voice  → wav bytes
  GET  {base}/v1/audio/list_voices      → {lang: {"voices": [...]}}
  GET  {base}/v1/health/ready

Hosted build.nvidia.com only exposes this over gRPC (function-id + bearer token),
which needs the `nvidia-riva-client` + grpc/protobuf stack. That's a documented
swap-in (RivaGRPCClient) behind the same protocol — not required to exercise the
rest of the voice pipeline, which only depends on the STTProvider/TTSProvider
protocols below.

When no speech_base_url is configured, NullSTT/NullTTS keep the pipeline runnable
offline (used in dev and in tests).
"""
from __future__ import annotations

from typing import Protocol

import httpx

from app.core.config import get_settings
from app.core.logging import get_logger

log = get_logger("voice.providers")


class VoiceError(RuntimeError):
    pass


# ── protocols ──────────────────────────────────────────────────────────────────

class STTProvider(Protocol):
    async def transcribe(self, audio: bytes, *, language: str = "en-US",
                         mime: str = "audio/wav") -> str: ...
    async def healthy(self) -> bool: ...


class TTSProvider(Protocol):
    async def synthesize(self, text: str, *, language: str = "en-US",
                         voice: str = "") -> bytes: ...
    async def list_voices(self) -> dict: ...
    async def healthy(self) -> bool: ...


# ── Riva HTTP implementation ──────────────────────────────────────────────────

class RivaHTTPClient:
    """Shared HTTP client for a self-hosted Riva Speech NIM instance."""

    def __init__(self, base_url: str, api_key: str = "", timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._http = httpx.AsyncClient(base_url=self.base_url, headers=headers, timeout=timeout)

    async def healthy(self) -> bool:
        try:
            r = await self._http.get("/v1/health/ready")
            return r.status_code == 200
        except httpx.HTTPError:
            return False

    async def aclose(self) -> None:
        await self._http.aclose()


class RivaSTT(RivaHTTPClient):
    async def transcribe(self, audio: bytes, *, language: str = "en-US",
                         mime: str = "audio/wav") -> str:
        try:
            resp = await self._http.post(
                "/v1/audio/transcriptions",
                data={"language": language},
                files={"file": ("utterance.wav", audio, mime)},
            )
            resp.raise_for_status()
            data = resp.json()
            # NIM returns an OpenAI-Whisper-shaped {"text": "..."} on success
            return data.get("text", "").strip()
        except (httpx.HTTPError, ValueError) as exc:
            raise VoiceError(f"STT request failed: {exc}") from exc


class RivaTTS(RivaHTTPClient):
    async def synthesize(self, text: str, *, language: str = "en-US",
                         voice: str = "") -> bytes:
        try:
            resp = await self._http.post(
                "/v1/audio/synthesize",
                data={"language": language, "text": text, "voice": voice},
            )
            resp.raise_for_status()
            return resp.content
        except httpx.HTTPError as exc:
            raise VoiceError(f"TTS request failed: {exc}") from exc

    async def list_voices(self) -> dict:
        try:
            resp = await self._http.get("/v1/audio/list_voices")
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise VoiceError(f"list_voices failed: {exc}") from exc


# ── offline fallbacks ──────────────────────────────────────────────────────────

class NullSTT:
    """Keeps the pipeline runnable with no speech backend configured."""
    async def transcribe(self, audio: bytes, *, language: str = "en-US",
                         mime: str = "audio/wav") -> str:
        log.info("stt_offline_noop", bytes=len(audio))
        return ""

    async def healthy(self) -> bool:
        return False


class NullTTS:
    async def synthesize(self, text: str, *, language: str = "en-US",
                         voice: str = "") -> bytes:
        log.info("tts_offline_noop", chars=len(text))
        return b""

    async def list_voices(self) -> dict:
        return {}

    async def healthy(self) -> bool:
        return False


# ── factory ───────────────────────────────────────────────────────────────────

def build_providers() -> tuple[STTProvider, TTSProvider]:
    s = get_settings()
    if s.speech_base_url:
        return (
            RivaSTT(s.speech_base_url, s.speech_api_key),
            RivaTTS(s.speech_base_url, s.speech_api_key),
        )
    log.info("voice_offline_fallback", reason="speech_base_url not configured")
    return NullSTT(), NullTTS()
