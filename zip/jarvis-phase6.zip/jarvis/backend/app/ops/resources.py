"""Resource monitoring + naive capacity planning.

GPU metrics: best-effort via `nvidia-smi` subprocess (no pynvml dependency
required); returns an empty list when no NVIDIA driver is present, which is
the normal case for a CPU-only dev box.
"""
from __future__ import annotations

import asyncio
import shutil

import psutil

from app.core.logging import get_logger

log = get_logger("ops.resources")


async def snapshot() -> dict:
    cpu = psutil.cpu_percent(interval=0.1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    return {
        "cpu_percent": cpu,
        "memory": {"percent": mem.percent, "used_gb": round(mem.used / 1e9, 2),
                   "total_gb": round(mem.total / 1e9, 2)},
        "disk": {"percent": disk.percent, "used_gb": round(disk.used / 1e9, 2),
                 "total_gb": round(disk.total / 1e9, 2)},
        "network": {"bytes_sent": net.bytes_sent, "bytes_recv": net.bytes_recv},
        "gpu": await _gpu_snapshot(),
    }


async def _gpu_snapshot() -> list[dict]:
    if shutil.which("nvidia-smi") is None:
        return []
    try:
        proc = await asyncio.create_subprocess_exec(
            "nvidia-smi",
            "--query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu",
            "--format=csv,noheader,nounits",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
        gpus = []
        for line in stdout.decode().strip().splitlines():
            idx, name, util, mem_used, mem_total, temp = [x.strip() for x in line.split(",")]
            gpus.append({
                "index": int(idx), "name": name, "utilization_percent": float(util),
                "memory_used_mb": float(mem_used), "memory_total_mb": float(mem_total),
                "temperature_c": float(temp),
            })
        return gpus
    except (asyncio.TimeoutError, OSError, ValueError) as exc:
        log.warning("gpu_snapshot_failed", error=str(exc))
        return []


def project_disk_exhaustion(history: list[dict]) -> dict | None:
    """
    Very simple linear projection: given a list of {"ts": iso, "used_gb": float}
    samples (e.g. backup sizes over time, or periodic disk snapshots), fit a
    straight line and estimate days until 100% full. Returns None if there's
    not enough signal (fewer than 2 points, or usage isn't trending up).
    """
    if len(history) < 2:
        return None
    from datetime import datetime
    xs = [datetime.fromisoformat(h["ts"]).timestamp() for h in history]
    ys = [h["used_gb"] for h in history]
    n = len(xs)
    mean_x, mean_y = sum(xs) / n, sum(ys) / n
    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    den = sum((x - mean_x) ** 2 for x in xs) or 1.0
    slope_gb_per_s = num / den   # GB per second
    if slope_gb_per_s <= 0:
        return {"trend": "stable_or_decreasing", "days_until_full": None}
    latest_used = ys[-1]
    # assume "total" capacity is whatever psutil reports right now isn't known
    # here — caller supplies it; this function only returns the trend rate.
    seconds_per_gb = 1 / slope_gb_per_s
    return {
        "trend": "increasing",
        "gb_per_day": round(slope_gb_per_s * 86400, 4),
        "seconds_per_additional_gb": round(seconds_per_gb, 1),
    }
