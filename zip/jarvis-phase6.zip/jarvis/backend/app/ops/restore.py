"""RestoreManager — full/partial restore with integrity validation and rollback.

Safety model: every real (non-dry-run) restore first takes a fresh backup of
current state via BackupManager, so "rollback" is never speculative — it's
"restore the snapshot we just took before touching anything."
"""
from __future__ import annotations

import json
import tarfile
import tempfile
from pathlib import Path

from app.core.config import get_settings
from app.core.logging import get_logger
from app.ops.backup import BackupManager
from app.ops.manifest import Manifest
from app.ops.targets import BackupTarget, TargetError

log = get_logger("ops.restore")

VALID_COMPONENTS = {"vault", "configs", "redis", "postgres"}


class RestoreError(RuntimeError):
    pass


class RestoreManager:
    def __init__(self, target: BackupTarget, backup_manager: BackupManager) -> None:
        self._target = target
        self._backups = backup_manager

    # ── fetch + validate ─────────────────────────────────────────────────
    async def _fetch_bundle(self, backup_id: str, staging: Path) -> Path:
        entry = self._backups.get_backup(backup_id)
        if entry is None:
            raise RestoreError(f"Backup {backup_id!r} not found in catalog")
        location = entry["location"]
        bundle_name = Path(location).name if "://" not in location else location.rsplit("/", 1)[-1]
        local_path = staging / bundle_name

        if Path(location).exists():
            import shutil
            shutil.copy2(location, local_path)
        else:
            try:
                await self._target.download(bundle_name, local_path)
            except TargetError as exc:
                raise RestoreError(f"Could not fetch backup: {exc}") from exc
        return local_path

    def _extract(self, bundle_path: Path, dest: Path) -> Manifest:
        with tarfile.open(bundle_path, "r:gz") as tar:
            tar.extractall(dest, filter="data")
        manifest_path = dest / "manifest.json"
        if not manifest_path.exists():
            raise RestoreError("Backup bundle missing manifest.json")
        return Manifest.from_json(manifest_path.read_text())

    async def validate(self, backup_id: str) -> dict:
        """Integrity check only — no restore performed."""
        with tempfile.TemporaryDirectory(prefix="jarvis-restore-check-") as tmp:
            staging = Path(tmp)
            bundle = await self._fetch_bundle(backup_id, staging)
            extracted = staging / "extracted"
            extracted.mkdir()
            manifest = self._extract(bundle, extracted)
            problems = manifest.verify_integrity(extracted)
            return {
                "backup_id": backup_id, "valid": not problems,
                "problems": problems, "components": manifest.components,
            }

    # ── component application ────────────────────────────────────────────
    def _apply_vault(self, extracted: Path) -> dict:
        archive = extracted / "vault.tar.gz"
        if not archive.exists():
            return {"status": "skipped", "reason": "not in this backup"}
        vault_root = Path(get_settings().obsidian_vault_path)
        vault_root.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(vault_root.parent, filter="data")
        return {"status": "ok"}

    def _apply_configs(self, extracted: Path) -> dict:
        archive = extracted / "configs.tar.gz"
        if not archive.exists():
            return {"status": "skipped", "reason": "not in this backup"}
        root = Path(__file__).resolve().parents[3]
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(root, filter="data")
        return {"status": "ok"}

    async def _apply_redis(self, extracted: Path) -> dict:
        archive = extracted / "redis.json"
        if not archive.exists():
            return {"status": "skipped", "reason": "not in this backup"}
        import redis.asyncio as aioredis
        try:
            r = aioredis.from_url(get_settings().redis_url, decode_responses=True)
            await r.ping()
        except Exception as exc:   # noqa: BLE001
            return {"status": "skipped", "reason": f"redis unreachable: {exc}"}
        data = json.loads(archive.read_text())
        try:
            for key, value in data.items():
                await r.set(key, value)
        finally:
            await r.aclose()
        return {"status": "ok", "keys_restored": len(data)}

    def _apply_postgres_note(self, extracted: Path) -> dict:
        archive = extracted / "postgres.sql"
        if not archive.exists():
            return {"status": "skipped", "reason": "not in this backup"}
        # Applying a SQL dump safely needs an operator-supervised psql run
        # (it's a destructive statement stream) — surface the path rather
        # than silently executing it inside the API request.
        return {"status": "manual_step_required",
               "note": f"Run: psql <DSN> -f {archive}"}

    # ── orchestration ─────────────────────────────────────────────────────
    async def restore(self, backup_id: str, *, components: list[str] | None = None,
                      dry_run: bool = False) -> dict:
        components = components or list(VALID_COMPONENTS)
        unknown = set(components) - VALID_COMPONENTS
        if unknown:
            raise RestoreError(f"Unknown component(s): {unknown}. Valid: {VALID_COMPONENTS}")

        check = await self.validate(backup_id)
        if not check["valid"]:
            raise RestoreError(f"Integrity check failed: {check['problems']}")

        if dry_run:
            return {"dry_run": True, "backup_id": backup_id,
                    "components_would_restore": components, "integrity": check}

        # safety snapshot before touching anything
        safety = await self._backups.create_backup(kind="full")
        log.info("restore_safety_snapshot", id=safety.id)

        with tempfile.TemporaryDirectory(prefix="jarvis-restore-") as tmp:
            staging = Path(tmp)
            bundle = await self._fetch_bundle(backup_id, staging)
            extracted = staging / "extracted"
            extracted.mkdir()
            self._extract(bundle, extracted)

            results: dict[str, dict] = {}
            if "vault" in components:
                results["vault"] = self._apply_vault(extracted)
            if "configs" in components:
                results["configs"] = self._apply_configs(extracted)
            if "redis" in components:
                results["redis"] = await self._apply_redis(extracted)
            if "postgres" in components:
                results["postgres"] = self._apply_postgres_note(extracted)

        log.info("restore_completed", backup_id=backup_id, results=results)
        return {
            "dry_run": False, "backup_id": backup_id,
            "safety_snapshot_id": safety.id,
            "results": results,
        }
