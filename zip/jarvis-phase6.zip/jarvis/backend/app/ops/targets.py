"""Backup destinations — pluggable BackupTarget protocol.

LocalTarget always works (stdlib only). S3Target and SFTPTarget lazy-import
their dependencies (boto3, paramiko) so the app boots fine without them —
they only fail when actually used without the dependency installed.
"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Protocol


class TargetError(RuntimeError):
    pass


class BackupTarget(Protocol):
    name: str
    async def upload(self, local_path: Path, remote_name: str) -> str:
        """Returns a location string describing where the file landed."""
        ...
    async def download(self, remote_name: str, local_path: Path) -> None: ...
    async def list_files(self) -> list[str]: ...


# ── Local / NAS (a NAS is just a mounted filesystem path) ─────────────────────

class LocalTarget:
    name = "local"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    async def upload(self, local_path: Path, remote_name: str) -> str:
        dest = self.root / remote_name
        if local_path.resolve() != dest.resolve():
            shutil.copy2(local_path, dest)
        return str(dest)

    async def download(self, remote_name: str, local_path: Path) -> None:
        src = self.root / remote_name
        if not src.exists():
            raise TargetError(f"Not found: {remote_name}")
        shutil.copy2(src, local_path)

    async def list_files(self) -> list[str]:
        return sorted(p.name for p in self.root.glob("*.tar.gz"))


# ── S3-compatible (AWS S3, MinIO, Cloudflare R2, ...) ──────────────────────────

class S3Target:
    name = "s3"

    def __init__(self, bucket: str, endpoint_url: str = "",
                access_key: str = "", secret_key: str = "", prefix: str = "jarvis-backups") -> None:
        try:
            import boto3  # noqa: F401  (import check only)
        except ImportError as exc:
            raise TargetError(
                "S3 backend requires 'boto3'. Install with: pip install boto3"
            ) from exc
        self.bucket = bucket
        self.prefix = prefix.strip("/")
        self._kwargs = {}
        if endpoint_url:
            self._kwargs["endpoint_url"] = endpoint_url
        if access_key:
            self._kwargs["aws_access_key_id"] = access_key
            self._kwargs["aws_secret_access_key"] = secret_key

    def _client(self):
        import boto3
        return boto3.client("s3", **self._kwargs)

    async def upload(self, local_path: Path, remote_name: str) -> str:
        import asyncio
        key = f"{self.prefix}/{remote_name}"
        await asyncio.to_thread(self._client().upload_file, str(local_path), self.bucket, key)
        return f"s3://{self.bucket}/{key}"

    async def download(self, remote_name: str, local_path: Path) -> None:
        import asyncio
        key = f"{self.prefix}/{remote_name}"
        try:
            await asyncio.to_thread(self._client().download_file, self.bucket, key, str(local_path))
        except Exception as exc:   # noqa: BLE001 — boto3 raises its own ClientError types
            raise TargetError(f"S3 download failed: {exc}") from exc

    async def list_files(self) -> list[str]:
        import asyncio
        resp = await asyncio.to_thread(
            self._client().list_objects_v2, Bucket=self.bucket, Prefix=f"{self.prefix}/"
        )
        return sorted(
            obj["Key"].rsplit("/", 1)[-1] for obj in resp.get("Contents", [])
        )


# ── SSH / SFTP ──────────────────────────────────────────────────────────────────

class SFTPTarget:
    name = "sftp"

    def __init__(self, host: str, username: str, key_path: str = "",
                remote_dir: str = "/backups/jarvis", port: int = 22) -> None:
        try:
            import paramiko  # noqa: F401
        except ImportError as exc:
            raise TargetError(
                "SFTP backend requires 'paramiko'. Install with: pip install paramiko"
            ) from exc
        self.host, self.port, self.username = host, port, username
        self.key_path = key_path
        self.remote_dir = remote_dir

    def _connect(self):
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = {"username": self.username}
        if self.key_path:
            kwargs["key_filename"] = self.key_path
        client.connect(self.host, port=self.port, **kwargs)
        return client

    async def upload(self, local_path: Path, remote_name: str) -> str:
        import asyncio

        def _do():
            client = self._connect()
            try:
                sftp = client.open_sftp()
                try:
                    sftp.mkdir(self.remote_dir)
                except OSError:
                    pass   # already exists
                remote_path = f"{self.remote_dir}/{remote_name}"
                sftp.put(str(local_path), remote_path)
                sftp.close()
            finally:
                client.close()
            return f"sftp://{self.host}{self.remote_dir}/{remote_name}"

        return await asyncio.to_thread(_do)

    async def download(self, remote_name: str, local_path: Path) -> None:
        import asyncio

        def _do():
            client = self._connect()
            try:
                sftp = client.open_sftp()
                sftp.get(f"{self.remote_dir}/{remote_name}", str(local_path))
                sftp.close()
            finally:
                client.close()

        try:
            await asyncio.to_thread(_do)
        except Exception as exc:   # noqa: BLE001
            raise TargetError(f"SFTP download failed: {exc}") from exc

    async def list_files(self) -> list[str]:
        import asyncio

        def _do():
            client = self._connect()
            try:
                sftp = client.open_sftp()
                names = sorted(f for f in sftp.listdir(self.remote_dir) if f.endswith(".tar.gz"))
                sftp.close()
                return names
            finally:
                client.close()

        return await asyncio.to_thread(_do)


def build_target(kind: str, **kwargs) -> BackupTarget:
    if kind == "local":
        return LocalTarget(kwargs["root"])
    if kind == "s3":
        return S3Target(**{k: v for k, v in kwargs.items() if k in
                           {"bucket", "endpoint_url", "access_key", "secret_key", "prefix"}})
    if kind == "sftp":
        return SFTPTarget(**{k: v for k, v in kwargs.items() if k in
                             {"host", "username", "key_path", "remote_dir", "port"}})
    raise TargetError(f"Unknown backup target kind: {kind!r}")
