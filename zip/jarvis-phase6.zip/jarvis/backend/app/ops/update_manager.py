"""UpdateManager — self-update workflow.

Steps (matching the spec's update workflow)
─────────────────────────────────────────────
1. Create backup              (safety net — via BackupManager)
2. Verify signature            (Ed25519, unless explicitly disabled)
3. Validate package             (per-file checksum integrity)
4. Run migrations               (alembic upgrade head, if migrations/ present)
5. Deploy                       (copy files into place)
6. Health checks                 (import smoke test + integrity re-check)
7. Switch traffic                 (no-op in single-process dev; documented
                                   hook for k8s rolling-update orchestration)
8. Confirm success                 (record UpdateRecord)

Any failure from step 4 onward triggers automatic rollback to the safety
backup taken in step 1, and the failure is recorded with a clear reason.
"""
from __future__ import annotations

import asyncio
import shutil
import subprocess
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from app.core.config import get_settings
from app.core.logging import get_logger
from app.ops.backup import BackupManager
from app.ops.manifest import Manifest
from app.ops.restore import RestoreManager
from app.ops.signing import verify

log = get_logger("ops.update")


def _now() -> datetime:
    return datetime.now(timezone.utc)


class UpdateError(RuntimeError):
    pass


@dataclass
class UpdateRecord:
    id: str = field(default_factory=lambda: str(uuid4()))
    version: str = ""
    status: str = "pending"        # pending|succeeded|failed|rolled_back
    applied_at: datetime = field(default_factory=_now)
    safety_backup_id: str | None = None
    steps: list[dict] = field(default_factory=list)
    error: str | None = None

    def step(self, name: str, ok: bool, detail: str = "") -> None:
        self.steps.append({"name": name, "ok": ok, "detail": detail,
                           "at": _now().isoformat()})

    def to_dict(self) -> dict:
        return {
            "id": self.id, "version": self.version, "status": self.status,
            "applied_at": self.applied_at.isoformat(),
            "safety_backup_id": self.safety_backup_id,
            "steps": self.steps, "error": self.error,
        }


def _extract_any(archive: Path, dest: Path) -> None:
    if archive.suffix == ".zip" or zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest)
    else:
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(dest, filter="data")


class UpdateManager:
    def __init__(self, backup_manager: BackupManager, restore_manager: RestoreManager) -> None:
        self._backups = backup_manager
        self._restore = restore_manager
        self._history: list[UpdateRecord] = []
        self._repo_root = Path(__file__).resolve().parents[3]   # jarvis/

    def history(self) -> list[dict]:
        return [r.to_dict() for r in self._history]

    def get(self, update_id: str) -> UpdateRecord | None:
        return next((r for r in self._history if r.id == update_id), None)

    # ── package staging ────────────────────────────────────────────────────
    def stage_package(self, package_path: Path) -> Path:
        """Copy an uploaded package into the staging dir, return the staged path."""
        staging_dir = Path(get_settings().update_staging_dir)
        staging_dir.mkdir(parents=True, exist_ok=True)
        dest = staging_dir / package_path.name
        shutil.copy2(package_path, dest)
        return dest

    # ── the workflow ───────────────────────────────────────────────────────
    async def apply_package(self, package_path: Path) -> UpdateRecord:
        settings = get_settings()
        record = UpdateRecord()

        with tempfile.TemporaryDirectory(prefix="jarvis-update-") as tmp:
            staging = Path(tmp)
            try:
                _extract_any(package_path, staging)
            except (tarfile.TarError, zipfile.BadZipFile, OSError) as exc:
                record.status, record.error = "failed", f"Could not extract package: {exc}"
                record.step("extract", False, str(exc))
                self._history.append(record)
                return record
            record.step("extract", True)

            manifest_path = staging / "manifest.json"
            if not manifest_path.exists():
                record.status, record.error = "failed", "Package missing manifest.json"
                record.step("validate_manifest", False, record.error)
                self._history.append(record)
                return record

            manifest = Manifest.from_json(manifest_path.read_text())
            record.version = manifest.version

            # 2 — verify signature
            sig_ok = True
            if settings.update_require_signature:
                if not manifest.signature or not settings.update_public_key:
                    sig_ok = False
                    record.step("verify_signature", False, "missing signature or no public key configured")
                else:
                    sig_ok = verify(manifest.signable_bytes(), manifest.signature, settings.update_public_key)
                    record.step("verify_signature", sig_ok,
                               "signature valid" if sig_ok else "signature INVALID")
            else:
                record.step("verify_signature", True, "skipped (update_require_signature=false)")

            if not sig_ok:
                record.status = "failed"
                record.error = "Signature verification failed — refusing to apply untrusted package"
                self._history.append(record)
                log.warning("update_rejected_bad_signature", version=manifest.version)
                return record

            # 3 — validate package integrity
            problems = manifest.verify_integrity(staging)
            record.step("validate_integrity", not problems, "; ".join(problems) if problems else "all checksums match")
            if problems:
                record.status, record.error = "failed", f"Integrity check failed: {problems}"
                self._history.append(record)
                return record

            # 1 — safety backup (taken after validation so we don't snapshot
            #     right before discovering the package itself is bad)
            try:
                safety = await self._backups.create_backup(kind="full")
                record.safety_backup_id = safety.id
                record.step("create_backup", True, safety.id)
            except Exception as exc:   # noqa: BLE001
                record.status, record.error = "failed", f"Safety backup failed, aborting: {exc}"
                record.step("create_backup", False, str(exc))
                self._history.append(record)
                return record

            # 4 — migrations (best effort — report, don't hard-fail the whole
            #     update if alembic isn't reachable from this environment)
            migrations_dir = staging / "migrations"
            if migrations_dir.exists():
                ok, detail = await self._run_migrations()
                record.step("run_migrations", ok, detail)
                if not ok:
                    await self._rollback(record, reason=f"migrations failed: {detail}")
                    return record
            else:
                record.step("run_migrations", True, "no migrations in package")

            # 5 — deploy: copy package contents over the repo, skipping
            #     manifest/release notes (metadata, not deployable files)
            try:
                self._deploy_files(staging, manifest)
                record.step("deploy", True, f"{len(manifest.files)} file(s) considered")
            except OSError as exc:
                record.step("deploy", False, str(exc))
                await self._rollback(record, reason=f"deploy failed: {exc}")
                return record

            # 6 — health check
            healthy, detail = self._health_check()
            record.step("health_check", healthy, detail)
            if not healthy:
                await self._rollback(record, reason=f"post-deploy health check failed: {detail}")
                return record

            # 7 — switch traffic (single-process dev: no-op; documented k8s hook)
            record.step("switch_traffic", True,
                       "no-op in this deployment mode — see docs/ARCHITECTURE.md for k8s rolling-update hook")

            # 8 — confirm
            record.status = "succeeded"
            record.step("confirm", True)
            log.info("update_applied", version=manifest.version, id=record.id)

        self._history.append(record)
        return record

    async def _run_migrations(self) -> tuple[bool, str]:
        backend_dir = self._repo_root / "backend"
        if not (backend_dir / "alembic.ini").exists():
            return True, "no alembic.ini found — skipped"
        try:
            proc = await asyncio.create_subprocess_exec(
                "python", "-m", "alembic", "upgrade", "head",
                cwd=str(backend_dir),
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
            if proc.returncode != 0:
                return False, stderr.decode()[:500]
            return True, stdout.decode()[:300]
        except (asyncio.TimeoutError, OSError) as exc:
            return False, str(exc)

    def _deploy_files(self, staging: Path, manifest: Manifest) -> None:
        skip = {"manifest.json", "release_notes.md"}
        for entry in manifest.files:
            if entry.path in skip:
                continue
            src = staging / entry.path
            if not src.exists():
                continue
            dst = self._repo_root / entry.path
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

    def _health_check(self) -> tuple[bool, str]:
        """Best-effort post-deploy smoke test: can the backend package still
        be imported cleanly? (Catches syntax errors / broken imports before
        anything tries to actually serve traffic on the new code.)"""
        backend_app = self._repo_root / "backend" / "app" / "main.py"
        if not backend_app.exists():
            return True, "no backend/app/main.py to check (frontend-only update?)"
        try:
            proc = subprocess.run(
                ["python", "-c", "import app.main"],
                cwd=str(self._repo_root / "backend"),
                capture_output=True, timeout=30, text=True,
            )
            if proc.returncode != 0:
                return False, proc.stderr[-500:]
            return True, "import smoke test passed"
        except Exception as exc:   # noqa: BLE001
            return False, str(exc)

    async def _rollback(self, record: UpdateRecord, reason: str) -> None:
        record.status = "failed"
        record.error = reason
        if record.safety_backup_id:
            try:
                await self._restore.restore(record.safety_backup_id)
                record.status = "rolled_back"
                record.step("rollback", True, f"restored backup {record.safety_backup_id}")
                log.warning("update_rolled_back", reason=reason, backup=record.safety_backup_id)
            except Exception as exc:   # noqa: BLE001
                record.step("rollback", False, str(exc))
                log.error("update_rollback_failed", reason=str(exc))
        self._history.append(record)
