"""Ed25519 signing/verification for self-update packages.

JARVIS never holds a private key — signing happens offline on a release
machine (see scripts/sign_update.py). The running app only verifies, using
a public key from config. This keeps the threat model simple: stealing the
running deployment's config can't let an attacker forge a trusted update.
"""
from __future__ import annotations

import base64

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


class SigningError(RuntimeError):
    pass


def generate_keypair() -> tuple[str, str]:
    """Returns (private_key_b64, public_key_b64). Run this once, offline,
    to produce your release signing key. Keep the private key off JARVIS."""
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()
    priv_bytes = priv.private_bytes_raw()
    pub_bytes = pub.public_bytes_raw()
    return base64.b64encode(priv_bytes).decode(), base64.b64encode(pub_bytes).decode()


def sign(data: bytes, private_key_b64: str) -> str:
    priv = Ed25519PrivateKey.from_private_bytes(base64.b64decode(private_key_b64))
    sig = priv.sign(data)
    return base64.b64encode(sig).decode()


def verify(data: bytes, signature_b64: str, public_key_b64: str) -> bool:
    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64))
        pub.verify(base64.b64decode(signature_b64), data)
        return True
    except (InvalidSignature, ValueError):
        return False
