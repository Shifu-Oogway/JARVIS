"""BackupManager — creates full/incremental backups as tar.gz archives.

Components
──────────
vault       tar of the Obsidian vault directory
configs     .env / docker-compose.yml / alembic.ini (whatever exists)
redis       logical dump: every jarvis:* key, scanned + JSON-serialised
            (portable across Redis versions — no raw RDB file access needed;
             this also captures scheduler jobs and workflow checkpoints)
postgres    pg_dump output, if reachable — gracefully SKIPPED (not failed)
            when pg_dump isn't on PATH or the DB can't be reached, since a
            backup of 3-out-of-4 components is still useful and a hard
            failure here would be worse than a documented partial backup

Incremental backups only re-tar vault files modified since the reference
backup's timestamp; configs/redis/postgres are small enough to always
capture in full. True incremental DB backup (WAL shipping) is future work.
"""
from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import redis.asyncio as aioredis

from app.core.config import get_settings
from app.core.logging import get_logger
from app.ops.manifest import Manifest
from app.ops.targets import BackupTarget, TargetError

log = get_logger("ops.backup")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _tag() -> str:
    return _now().strftime("%Y%m%d-%H%M%S")


class BackupManager:
    def __init__(self, default_target: BackupTarget) -> None:
        self._default_target = default_target
        self._catalog_path = Path(get_settings().backup_dir) / "catalog.json"
        self._catalog: list[dict] = self._load_catalog()

    # ── catalog (lightweight, file-based — survives without a DB) ────────────
    def _load_catalog(self) -> list[dict]:
        if self._catalog_path.exists():
            try:
                return json.loads(self._catalog_path.read_text())
            except (json.JSONDecodeError, OSError):
                return []
        return []

    def _save_catalog(self) -> None:
        self._catalog_path.parent.mkdir(parents=True, exist_ok=True)
        self._catalog_path.write_text(json.dumps(self._catalog, indent=2))

    def list_backups(self) -> list[dict]:
        return list(self._catalog)

    def get_backup(self, backup_id: str) -> dict | None:
        return next((b for b in self._catalog if b["id"] == backup_id), None)

    def latest_full(self) -> dict | None:
        fulls = [b for b in self._catalog if b["kind"] == "full"]
        return max(fulls, key=lambda b: b["created_at"]) if fulls else None

    # ── component capture ─────────────────────────────────────────────────
    async def _capture_vault(self, staging: Path, since: datetime | None) -> dict:
        vault_root = Path(get_settings().obsidian_vault_path)
        if not vault_root.exists():
            return {"status": "skipped", "reason": "vault path does not exist"}
        files = list(vault_root.rglob("*.md"))
        if since:
            files = [f for f in files if datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc) > since]
        if not files and since:
            return {"status": "ok", "files": 0, "note": "no changes since reference backup"}
        archive = staging / "vault.tar.gz"
        with tarfile.open(archive, "w:gz") as tar:
            for f in files:
                tar.add(f, arcname=f"vault/{f.relative_to(vault_root)}")
        return {"status": "ok", "files": len(files), "archive": "vault.tar.gz"}

    async def _capture_configs(self, staging: Path) -> dict:
        candidates = [".env", "docker-compose.yml", "backend/alembic.ini"]
        root = Path(__file__).resolve().parents[3]   # jarvis/ repo root
        found = [root / c for c in candidates if (root / c).exists()]
        if not found:
            return {"status": "skipped", "reason": "no config files found"}
        archive = staging / "configs.tar.gz"
        with tarfile.open(archive, "w:gz") as tar:
            for f in found:
                tar.add(f, arcname=f"configs/{f.name}")
        return {"status": "ok", "files": [f.name for f in found], "archive": "configs.tar.gz"}

    async def _capture_redis(self, staging: Path) -> dict:
        try:
            r = aioredis.from_url(get_settings().redis_url, decode_responses=True)
            await r.ping()
        except Exception as exc:   # noqa: BLE001
            return {"status": "skipped", "reason": f"redis unreachable: {exc}"}

        dump: dict[str, str] = {}
        try:
            async for key in r.scan_iter(match="jarvis:*"):
                try:
                    dump[key] = await r.get(key) or ""
                except Exception:   # noqa: BLE001 — non-string types (lists/hashes) skipped individually
                    continue
        finally:
            await r.aclose()

        archive = staging / "redis.json"
        archive.write_text(json.dumps(dump, indent=2))
        return {"status": "ok", "keys": len(dump), "archive": "redis.json"}

    async def _capture_postgres(self, staging: Path) -> dict:
        if shutil.which("pg_dump") is None:
            return {"status": "skipped", "reason": "pg_dump not found on PATH"}
        dsn = get_settings().database_url.replace("+asyncpg", "")   # pg_dump wants a plain postgresql:// URL
        out = staging / "postgres.sql"
        try:
            proc = await asyncio.create_subprocess_exec(
                "pg_dump", dsn, "-f", str(out),
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
            if proc.returncode != 0:
                return {"status": "skipped", "reason": stderr.decode()[:300]}
        except (asyncio.TimeoutError, OSError) as exc:
            return {"status": "skipped", "reason": str(exc)}
        return {"status": "ok", "archive": "postgres.sql"}

    # ── orchestration ─────────────────────────────────────────────────────
    async def create_backup(self, kind: str = "full",
                            target: BackupTarget | None = None) -> Manifest:
        if kind not in ("full", "incremental"):
            raise ValueError("kind must be 'full' or 'incremental'")

        target = target or self._default_target
        since = None
        if kind == "incremental":
            ref = self.latest_full() or (self._catalog[-1] if self._catalog else None)
            if ref:
                since = datetime.fromisoformat(ref["created_at"])

        tag = _tag()
        manifest = Manifest(kind="backup", version=tag)

        with tempfile.TemporaryDirectory(prefix="jarvis-backup-") as tmp:
            staging = Path(tmp)
            manifest.components["vault"]    = await self._capture_vault(staging, since)
            manifest.components["configs"]  = await self._capture_configs(staging)
            manifest.components["redis"]    = await self._capture_redis(staging)
            manifest.components["postgres"] = await self._capture_postgres(staging)

            for f in staging.iterdir():
                manifest.add_file(f.name, f)

            manifest_path = staging / "manifest.json"
            manifest_path.write_text(manifest.to_json())

            bundle_name = f"jarvis-backup-{kind}-{tag}-{manifest.id[:8]}.tar.gz"
            bundle_path = staging.parent / bundle_name
            with tarfile.open(bundle_path, "w:gz") as tar:
                for f in staging.iterdir():
                    tar.add(f, arcname=f.name)

            size = bundle_path.stat().st_size
            try:
                location = await target.upload(bundle_path, bundle_name)
            except TargetError as exc:
                log.warning("backup_upload_failed", error=str(exc))
                location = str(bundle_path)   # at least keep it locally describable
            finally:
                bundle_path.unlink(missing_ok=True)

        entry = {
            "id": manifest.id, "kind": kind, "tag": tag,
            "created_at": manifest.created_at.isoformat(),
            "location": location, "size_bytes": size,
            "target": target.name, "components": manifest.components,
            "digest": manifest.overall_digest(),
        }
        self._catalog.append(entry)
        self._save_catalog()
        log.info("backup_created", id=manifest.id, kind=kind, size=size, location=location)
        return manifest
