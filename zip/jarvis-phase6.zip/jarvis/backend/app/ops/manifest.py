"""Manifest model — shared by the backup system and the self-update system.

A manifest is the contract for "what is in this archive and how do we know
it's intact": per-file SHA-256 checksums plus an overall digest. Update
manifests additionally carry an Ed25519 signature over the canonical bytes.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def _now() -> datetime:
    return datetime.now(timezone.utc)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class FileEntry:
    path: str          # relative path within the archive
    sha256: str
    size: int

    def to_dict(self) -> dict:
        return {"path": self.path, "sha256": self.sha256, "size": self.size}


@dataclass
class Manifest:
    id: str = field(default_factory=lambda: str(uuid4()))
    kind: str = "backup"          # "backup" | "update"
    version: str = ""              # update packages: semver; backups: timestamp tag
    created_at: datetime = field(default_factory=_now)
    files: list[FileEntry] = field(default_factory=list)
    components: dict[str, dict] = field(default_factory=dict)   # backup-specific status per component
    signature: str | None = None   # base64 Ed25519 signature (update packages only)
    notes: str = ""

    def add_file(self, rel_path: str, abs_path: Path) -> None:
        self.files.append(FileEntry(rel_path, sha256_file(abs_path), abs_path.stat().st_size))

    def overall_digest(self) -> str:
        """Deterministic digest over sorted file entries — what gets signed."""
        canonical = json.dumps(
            [f.to_dict() for f in sorted(self.files, key=lambda f: f.path)],
            sort_keys=True,
        )
        return sha256_bytes(canonical.encode())

    def signable_bytes(self) -> bytes:
        """Bytes that get signed/verified — everything except the signature itself."""
        d = self.to_dict()
        d.pop("signature", None)
        return json.dumps(d, sort_keys=True).encode()

    def to_dict(self) -> dict:
        return {
            "id": self.id, "kind": self.kind, "version": self.version,
            "created_at": self.created_at.isoformat(),
            "files": [f.to_dict() for f in self.files],
            "components": self.components,
            "signature": self.signature,
            "notes": self.notes,
            "digest": self.overall_digest(),
        }

    def to_json(self, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, d: dict) -> "Manifest":
        m = cls(
            id=d.get("id", str(uuid4())), kind=d.get("kind", "backup"),
            version=d.get("version", ""), components=d.get("components", {}),
            signature=d.get("signature"), notes=d.get("notes", ""),
        )
        if d.get("created_at"):
            m.created_at = datetime.fromisoformat(d["created_at"])
        m.files = [FileEntry(**f) for f in d.get("files", [])]
        return m

    @classmethod
    def from_json(cls, raw: str) -> "Manifest":
        return cls.from_dict(json.loads(raw))

    def verify_integrity(self, root: Path) -> list[str]:
        """Check every file's checksum against what's on disk under `root`.
        Returns a list of problem descriptions (empty = all good)."""
        problems = []
        for f in self.files:
            full = root / f.path
            if not full.exists():
                problems.append(f"missing: {f.path}")
                continue
            actual = sha256_file(full)
            if actual != f.sha256:
                problems.append(f"checksum mismatch: {f.path}")
        return problems
